
import csv
import os
import threading
import logging
import random
import math
import secrets
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Optional, Dict, List, Set, Any
from iazar.generator.config_loader import config_loader
from iazar.generator.randomx_validator import RandomXValidator
from iazar.generator.NonceCSVWriter import NonceCSVWriter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

STANDARD_FIELDNAMES = [
    "nonce", "entropy", "uniqueness", "zero_density",
    "pattern_score", "is_valid", "block_height"
]

# ✅ Clase base abstracta para todos los generadores
class BaseNonceGenerator(ABC):
    def __init__(self, generator_name: str, config: Optional[Dict] = None):
        self.generator_name = generator_name
        self.config = config or config_loader.load_config()
        self.lock = threading.Lock()
        self._last_mtime = 0
        self.training_data = self._load_training_data()
        self.writer = NonceCSVWriter(self.config["data_paths"]["generated_nonces"])
        logging.info(f"[{generator_name}] Initialized.")

    def _get_data_path(self, key: str) -> str:
        return self.config["data_paths"].get(key, "")

    def _maybe_reload_training_data(self):
        path = self._get_data_path('training_data')
        if not path or not os.path.exists(path):
            return
        current_mtime = os.path.getmtime(path)
        if current_mtime > self._last_mtime:
            self.training_data = self._load_training_data()
            self._last_mtime = current_mtime
            logging.info(f"[{self.generator_name}] Training data reloaded.")

    def _load_training_data(self) -> List[dict]:
        path = self._get_data_path('training_data')
        if not path or not os.path.exists(path):
            logging.warning(f"[{self.generator_name}] Training data file not found: {path}")
            return []
        try:
            with open(path, 'r', newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                return [row for row in reader if row.get('nonce')]
        except Exception as e:
            logging.error(f"[{self.generator_name}] Error loading training data: {e}")
            return []

    @abstractmethod
    def run_generation(self, block_height: int, block_data: dict) -> List[dict]:
        pass

# ✅ Implementación concreta que hereda de BaseNonceGenerator
class GroupedTopNonceGenerator(BaseNonceGenerator):
    """
    Generador de nonces tipo grupo-top para minería de Monero optimizada.
    - Cumple formato estricto para batch processing.
    - Usa NonceCSVWriter universal para escritura.
    - Entrenamiento basado en históricos.
    """
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__("grouped_top", config)
        self.validator = RandomXValidator(self.config)
        self.num_groups = self.config.get("num_groups", 16)
        self.top_groups = self.config.get("top_groups", 4)
        self.batch_size = self.config.get("batch_size", 500)
        self.max_attempts = self.config.get("max_attempts", 10_000)
        logging.info(f"[GroupedTopNonceGenerator] Loaded {len(self.training_data)} training nonces.")

    def _analyze_group_performance(self) -> Dict[int, float]:
        group_success = defaultdict(int)
        group_total = defaultdict(int)
        for row in self.training_data:
            try:
                nonce = int(row['nonce'])
                group_id = nonce % self.num_groups
                group_total[group_id] += 1
                if row.get('is_valid', 'False').lower() == 'true':
                    group_success[group_id] += 1
            except Exception:
                continue
        success_rates = {gid: (group_success[gid] / group_total[gid]) if group_total[gid] > 0 else 0.0 for gid in group_total}
        return success_rates

    def _select_top_groups(self) -> List[int]:
        success_rates = self._analyze_group_performance()
        available_groups = list(success_rates.keys())
        top_n = min(self.top_groups, len(available_groups))
        if not available_groups:
            logging.warning("[GroupedTopNonceGenerator] No groups available for selection")
            return []
        sorted_groups = sorted(
            available_groups,
            key=lambda g: (success_rates[g], g),
            reverse=True
        )
        return sorted_groups[:top_n]

    def _generate_nonce_for_group(self, group_id: int) -> int:
        base_nonce = secrets.randbits(64)
        adjustment = (group_id - (base_nonce % self.num_groups)) % self.num_groups
        return (base_nonce + adjustment) % (1 << 64)

    def _calc_shannon_entropy(self, binary: str) -> float:
        if not binary:
            return 0.0
        char_counts = {}
        for char in binary:
            char_counts[char] = char_counts.get(char, 0) + 1
        entropy = 0.0
        total = len(binary)
        for count in char_counts.values():
            p = count / total
            entropy -= p * math.log2(p)
        return entropy

    def _calc_zero_density(self, binary: str) -> float:
        return binary.count('0') / len(binary) if binary else 0.0

    def _calc_pattern_score(self, binary: str) -> float:
        if len(binary) < 4:
            return 1.0
        max_run = 0
        current_run = 1
        last_char = binary[0]
        for char in binary[1:]:
            if char == last_char:
                current_run += 1
                max_run = max(max_run, current_run)
            else:
                current_run = 1
            last_char = char
        return 1.0 - (max_run / len(binary))

    def _calc_uniqueness(self, nonce: int, seen_set: Set[int]) -> float:
        return 1.0 if nonce not in seen_set else 0.0

    def run_generation(self, block_height: int, block_data: dict) -> List[dict]:
        self._maybe_reload_training_data()
        top_groups = self._select_top_groups()
        if not top_groups:
            logging.error("[GroupedTopNonceGenerator] No groups available for generation")
            return []
        
        nonces = []
        attempts = 0
        seen: Set[int] = set()
        
        while len(nonces) < self.batch_size and attempts < self.max_attempts:
            group_id = random.choice(top_groups)
            nonce = self._generate_nonce_for_group(group_id)
            
            if nonce in seen:
                attempts += 1
                continue
                
            bin_str = bin(nonce)[2:].zfill(64)
            metrics = {
                "entropy": self._calc_shannon_entropy(bin_str),
                "uniqueness": self._calc_uniqueness(nonce, seen),
                "zero_density": self._calc_zero_density(bin_str),
                "pattern_score": self._calc_pattern_score(bin_str),
            }
            
            try:
                is_valid = self.validator.validate(nonce, block_data)
            except Exception as e:
                logging.error(f"[GroupedTopNonceGenerator] Validation error: {e}")
                is_valid = False
                
            nonce_data = {
                "nonce": nonce,
                "block_height": block_height,
                "is_valid": is_valid,
                **metrics
            }
            
            seen.add(nonce)
            nonces.append(nonce_data)
            attempts += 1
            
        return nonces