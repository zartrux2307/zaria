import os
import csv
import time
import random
import logging
import threading
from typing import Dict, List, Set, Optional
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

from iazar.generator.nonce_generator import BaseNonceGenerator
from iazar.generator.randomx_validator import RandomXValidator

# Directorio base para datos
DATA_DIR = './data'

class SequenceBasedGenerator(BaseNonceGenerator):
    """
    Generador de nonces basado en secuencias para minería de Monero optimizada.
    - Genera nonces usando progresiones aritméticas modificadas con operaciones binarias
    - Incorpora componentes aleatorios para evitar patrones predecibles
    - Industrial-grade para minería enterprise de Monero/RandomX
    """
    RECENT_NONCES_SIZE = 500
    MAX_VALIDATION_WORKERS = max(2, min(16, os.cpu_count() or 4))
    
    # Campos consistentes en toda la arquitectura
    FIELDNAMES = [
        "nonce", "entropy", "uniqueness", "zero_density", 
        "pattern_score", "is_valid", "block_height"
    ]

    def __init__(self, config: Optional[Dict] = None):
        super().__init__("sequence", config)
        self.lock = threading.RLock()
        self.validator = RandomXValidator(self.config)
        self._log("SequenceBasedGenerator inicializado.")

    def _get_data_path(self, key: str) -> str:
        """Obtener ruta de datos profesional"""
        return os.path.join(DATA_DIR, f"{self.generator_name}_{key}.csv")
    
    def _log(self, msg: str, level="info"):
        logger = logging.getLogger("SequenceBasedGenerator")
        if not logger.hasHandlers():
            logging.basicConfig(level=logging.INFO)
        getattr(logger, level, logger.info)(msg)

    def _get_recent_nonces(self) -> Set[int]:
        """Carga los nonces válidos más recientes desde archivo"""
        path = self._get_data_path('generated_nonces')
        recent = set()
        if not os.path.exists(path):
            return recent
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                for row in reversed(rows):
                    if len(recent) >= self.RECENT_NONCES_SIZE:
                        break
                    try:
                        if row.get('is_valid', 'False').lower() == 'true':
                            recent.add(int(row['nonce']))
                    except (ValueError, KeyError):
                        continue
            self._log(f"Cargados {len(recent)} nonces recientes")
        except Exception as e:
            self._log(f"Error cargando nonces recientes: {e}", level="error")
        return recent

    def _generate_candidates(self, n: int) -> List[int]:
        """Genera candidatos usando secuencia lineal + perturbación no lineal"""
        rng = random.SystemRandom()
        base = rng.getrandbits(64)
        step = rng.getrandbits(64) | 1  # Asegura que sea impar
        perturbations = [rng.getrandbits(64) for _ in range(n)]
        
        candidates = []
        seen = set()
        
        for i in range(n):
            # Secuencia lineal con perturbación XOR
            candidate = (base + i * step) ^ perturbations[i]
            candidate %= (2**64)  # Asegura 64 bits
            
            # Manejo de colisiones
            if candidate in seen:
                candidate = rng.getrandbits(64)
                while candidate in seen:
                    candidate = rng.getrandbits(64)
            
            seen.add(candidate)
            candidates.append(candidate)
        
        return candidates

    def _calculate_metrics(self, nonce: int, recent_set: Set[int]) -> dict:
        """Cálculo profesional de métricas de calidad"""
        bin_repr = bin(nonce)[2:].zfill(64)
        arr = np.array([int(b) for b in bin_repr], dtype=np.uint8)
        
        # Cálculo de entropía
        p0 = np.count_nonzero(arr == 0) / 64.0
        p1 = 1 - p0
        entropy = - (p0 * np.log2(p0 + 1e-12) + p1 * np.log2(p1 + 1e-12))
        
        # Densidad de ceros
        zero_density = p0
        
        # Patrones de ejecución
        run_lengths = np.diff(np.where(np.concatenate(([0], arr[:-1] != arr[1:], [0])))[0])
        max_run = np.max(run_lengths) if run_lengths.size > 0 else 0
        transitions = np.sum(arr[:-1] != arr[1:])
        
        # Puntaje de patrón (evita ejecuciones largas)
        pattern_score = max(0.5, 1.0 - min(0.3, max_run / 32) + min(0.2, transitions / 63))
        
        # Uniqueness
        uniqueness = self._calculate_uniqueness(nonce, recent_set)
        
        return {
            "entropy": round(entropy, 5),
            "uniqueness": round(uniqueness, 5),
            "zero_density": round(zero_density, 5),
            "pattern_score": round(pattern_score, 5)
        }

    def _calculate_uniqueness(self, nonce: int, recent_set: Set[int]) -> float:
        """Distancia de Hamming promedio contra nonces recientes"""
        if not recent_set:
            return 1.0
        nonce_arr = np.full(len(recent_set), nonce, dtype=np.uint64)
        recent_arr = np.array(list(recent_set), dtype=np.uint64)
        xor_arr = np.bitwise_xor(nonce_arr, recent_arr)
        popcnts = np.vectorize(lambda x: bin(x).count('1'))(xor_arr)
        avg_distance = np.mean(popcnts)
        return max(0.8, min(0.99, avg_distance / 64))

    def _validate_batch(self, nonces: List[int], block_data: dict) -> List[bool]:
        """Validación paralela de candidatos"""
        if not nonces:
            return []
        results = [False] * len(nonces)
        with ThreadPoolExecutor(max_workers=self.MAX_VALIDATION_WORKERS) as executor:
            future_map = {executor.submit(self.validator.validate, n, block_data): i 
                          for i, n in enumerate(nonces)}
            for future in as_completed(future_map):
                idx = future_map[future]
                try:
                    results[idx] = bool(future.result())
                except Exception as e:
                    self._log(f"Validación fallida para idx {idx}: {e}", level="error")
        return results

    def _save_nonces_batch(self, nonces: List[dict]):
        """Guarda nonces en formato CSV"""
        if not nonces:
            return
        output_path = self._get_data_path('generated_nonces')
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        file_exists = os.path.exists(output_path)
        
        try:
            with open(output_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
                if not file_exists:
                    writer.writeheader()
                writer.writerows([{k: v for k, v in item.items() 
                                  if k in self.FIELDNAMES} 
                                 for item in nonces])
        except Exception as e:
            self._log(f"Error guardando nonces: {e}", level="error")

    def run_generation(self, block_height: int, block_data: dict, batch_size: int = 500) -> List[dict]:
        """Genera un lote de nonces válidos"""
        with self.lock:
            t0 = time.time()
            recent_nonces = self._get_recent_nonces()
            candidates = self._generate_candidates(4 * batch_size)
            validation = self._validate_batch(candidates, block_data)
            
            valid_nonces = []
            for i, nonce in enumerate(candidates):
                if validation[i]:
                    metrics = self._calculate_metrics(nonce, recent_nonces)
                    valid_nonces.append({
                        "nonce": nonce,
                        "entropy": metrics["entropy"],
                        "uniqueness": metrics["uniqueness"],
                        "zero_density": metrics["zero_density"],
                        "pattern_score": metrics["pattern_score"],
                        "is_valid": True,
                        "block_height": block_height
                    })
                    recent_nonces.add(nonce)
                    
                    if len(valid_nonces) >= batch_size:
                        break
            
            self._save_nonces_batch(valid_nonces)
            elapsed = time.time() - t0
            self._log(
                f"Block {block_height}: Generados {len(valid_nonces)} nonces válidos | "
                f"Tiempo: {elapsed:.2f}s | "
                f"Velocidad: {len(valid_nonces)/elapsed:.1f} nonces/s"
            )
            return valid_nonces