import csv
import os
from typing import List, Dict, Optional
import threading

STANDARD_FIELDNAMES = [
    "nonce", "entropy", "uniqueness", "zero_density",
    "pattern_score", "is_valid", "block_height"
]

class NonceCSVWriter:
    """
    Writer universal enterprise para nonces: garantiza campos correctos,
    escribe batch, auto-flush, thread-safe, y evita errores de fieldnames.
    Versión 2.0 con optimización para alta concurrencia.
    """
    _instances = {}
    _lock = threading.Lock()
    
    def __new__(cls, file_path: str, fieldnames: List[str] = None, batch_size: int = 1000):
        """Singleton por file_path para evitar conflictos de escritura."""
        with cls._lock:
            if file_path not in cls._instances:
                cls._instances[file_path] = super().__new__(cls)
            return cls._instances[file_path]
    
    def __init__(self, file_path: str, fieldnames: List[str] = None, batch_size: int = 1000):
        if not hasattr(self, '_initialized'):  # Evitar reinicialización en singleton
            self.file_path = file_path
            self.FIELDNAMES = fieldnames or STANDARD_FIELDNAMES
            self.buffer = []
            self.batch_size = batch_size
            self.write_lock = threading.Lock()
            self._initialized = True

    def write(self, row: Dict):
        """Añade fila al buffer con thread-safety."""
        filtered = {k: v for k, v in row.items() if k in self.FIELDNAMES}
        
        with self.write_lock:
            self.buffer.append(filtered)
            if len(self.buffer) >= self.batch_size:
                self.flush()

    def flush(self):
        """Escribe buffer en disco con thread-safety."""
        with self.write_lock:
            if not self.buffer:
                return
            
            buffer_to_write = self.buffer.copy()
            self.buffer = []
        
        # Operación I/O fuera del lock principal
        file_exists = os.path.exists(self.file_path)
        with open(self.file_path, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
            if not file_exists:
                writer.writeheader()
            writer.writerows(buffer_to_write)

    def close(self):
        """Garantiza que todos los datos se escriban al cerrar."""
        self.flush()
        
    @classmethod
    def close_all(cls):
        """Cierra todas las instancias al finalizar la aplicación."""
        for instance in cls._instances.values():
            instance.close()