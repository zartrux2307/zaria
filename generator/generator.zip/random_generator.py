import random
import logging
from iazar.generator.nonce_generator import NonceGenerator
from iazar.utils import randomx_wrapper

logger = logging.getLogger("RandomGenerator")

class RandomGenerator(NonceGenerator):
    def __init__(self, config=None):
        super().__init__(config)
        self.block_blob = None
        self.seed_hash = None
        self.target = None
        self.nonce_offset = 39  # Offset estándar para Monero, ajusta si tu blob cambia

    def set_job(self, block_blob, seed_hash, target):
        """Recibe los parámetros del job actual para minado real."""
        self.block_blob = block_blob
        self.seed_hash = seed_hash
        self.target = target

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000
        if not (self.block_blob and self.seed_hash and self.target):
            logger.warning("No hay job seteado. Generando nonces aleatorios sin validación.")
            return super().generate(count)
        valid_nonces = []
        tries = 0
        max_tries = count * 5  # Límite de iteraciones para no colgarse
        while len(valid_nonces) < count and tries < max_tries:
            nonce = random.getrandbits(32)
            blob_with_nonce = self.insert_nonce(nonce)
            try:
                block_hash = randomx_wrapper.compute_randomx_hash(
                    blob=blob_with_nonce,
                    nonce=nonce,
                    seed=self.seed_hash
                )
                if randomx_wrapper.hash_meets_target(block_hash, self.target):
                    valid_nonces.append(nonce)
            except Exception as e:
                logger.error(f"Error calculando hash: {str(e)}", exc_info=True)
            tries += 1
        if len(valid_nonces) < count:
            logger.warning(f"Sólo se generaron {len(valid_nonces)} nonces válidos de {count} solicitados.")
        return valid_nonces

    def insert_nonce(self, nonce):
        # Inserta el nonce en el offset correcto dentro del blob (little-endian)
        mutable_blob = bytearray(self.block_blob)
        mutable_blob[self.nonce_offset:self.nonce_offset + 4] = nonce.to_bytes(4, "little")
        return bytes(mutable_blob)
