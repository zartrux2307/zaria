import csv
import random
import logging
from iazar.generator.nonce_generator import NonceGenerator
from iazar.utils.paths import get_nonce_training_data_path
from iazar.generator.paths import get_model_path

logger = logging.getLogger("SequenceBasedGenerator")

class SequenceBasedGenerator(NonceGenerator):
    def __init__(self, config=None):
        super().__init__(config)
        self.sequences = self.cargar_secuencias()
        self.current_sequence = 0

    def cargar_secuencias(self):
        secuencias = []
        try:
            # Si tu path cambia, solo ajusta get_nonce_training_data_path
            data_path = get_nonce_training_data_path()
            with open(data_path, 'r', encoding="utf-8") as f:
                reader = csv.DictReader(f)
                nonces = []
                for row in reader:
                    try:
                        nonce_val = row['nonce']
                        # Si el valor es hexadecimal o texto, lo convierte
                        if 'x' in nonce_val or 'X' in nonce_val or nonce_val.startswith('F'):
                            nonces.append(int(nonce_val, 16))
                        else:
                            nonces.append(int(nonce_val))
                    except Exception:
                        pass
                if nonces:
                    sequence = [nonces[0]]
                    last_nonce = nonces[0]
                    for nonce in nonces[1:]:
                        if nonce == last_nonce + 1:
                            sequence.append(nonce)
                        else:
                            if len(sequence) >= 3:
                                secuencias.append(sequence.copy())
                            sequence = [nonce]
                        last_nonce = nonce
                    if len(sequence) >= 3:
                        secuencias.append(sequence)
            logger.info(f"✅ Cargadas {len(secuencias)} secuencias de patrones")
            return secuencias
        except Exception as e:
            logger.error(f"❌ Error cargando secuencias: {str(e)}")
            return []

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000
        if not self.sequences:
            logger.warning("⚠️ No se encontraron secuencias, usando fallback (pseudoaleatorio).")
            return super().generate(count)
        seq = self.sequences[self.current_sequence]
        self.current_sequence = (self.current_sequence + 1) % len(self.sequences)
        if len(seq) < count:
            logger.info("🔗 Combinando secuencia detectada + aleatorio para completar cantidad solicitada")
            return seq + super().generate(count - len(seq))
        return seq[:count]
