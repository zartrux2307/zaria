import logging
import random
from iazar.generator.nonce_generator import NonceGenerator

logger = logging.getLogger("AdaptiveGenerator")

class AdaptiveGenerator(NonceGenerator):
    """
    Generador adaptativo profesional para nonces.
    Ajusta su rango y probabilidad en función del historial de éxitos recientes.
    """

    def __init__(self, config=None):
        super().__init__(config)
        self.state = {
            "recent_success": [],
            "bad_ranges": set(),
            "min_nonce": 0,
            "max_nonce": 2**32 - 1,
        }
        self.window_size = 100  # Cambia el rango de análisis si quieres

    def set_state(self, state):
        # Permite actualizar el estado desde fuera
        if not state:
            return
        self.state.update(state)

    def register_success(self, nonce):
        # Llama esto cuando un nonce haya tenido éxito
        self.state["recent_success"].append(nonce)
        if len(self.state["recent_success"]) > self.window_size:
            self.state["recent_success"].pop(0)

    def register_failure(self, nonce):
        # Llama esto si un nonce es especialmente malo
        self.state["bad_ranges"].add(self._nonce_to_range(nonce))

    def _nonce_to_range(self, nonce, total_bins=10):
        bin_size = (self.state["max_nonce"] - self.state["min_nonce"]) // total_bins
        return (nonce - self.state["min_nonce"]) // bin_size

    def get_hot_ranges(self, bins=10):
        # Analiza los nonces exitosos recientes para identificar rangos calientes
        if not self.state["recent_success"]:
            return [(self.state["min_nonce"], self.state["max_nonce"])]
        bin_size = (self.state["max_nonce"] - self.state["min_nonce"]) // bins
        heatmap = [0 for _ in range(bins)]
        for nonce in self.state["recent_success"]:
            idx = min((nonce - self.state["min_nonce"]) // bin_size, bins - 1)
            heatmap[idx] += 1
        max_hits = max(heatmap)
        hot_bins = [i for i, hits in enumerate(heatmap) if hits == max_hits and hits > 0]
        ranges = []
        for i in hot_bins:
            start = self.state["min_nonce"] + i * bin_size
            end = start + bin_size - 1
            ranges.append((start, min(end, self.state["max_nonce"])))
        return ranges or [(self.state["min_nonce"], self.state["max_nonce"])]

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000

        # Obtén los rangos calientes (hot ranges)
        hot_ranges = self.get_hot_ranges(bins=10)

        # Pondera los rangos calientes
        results = []
        for _ in range(count):
            start, end = random.choice(hot_ranges)
            nonce = random.randint(start, end)
            # Opcional: Evita rangos malos conocidos
            if self._nonce_to_range(nonce) not in self.state["bad_ranges"]:
                results.append(nonce)
            else:
                # Busca hasta acertar fuera de rangos malos
                for _ in range(5):
                    nonce = random.randint(self.state["min_nonce"], self.state["max_nonce"])
                    if self._nonce_to_range(nonce) not in self.state["bad_ranges"]:
                        results.append(nonce)
                        break
                else:
                    # Si no puede, agrega igual
                    results.append(nonce)
        return results
