import os
import joblib
import numpy as np
import pandas as pd
import logging

from sklearn.ensemble import RandomForestRegressor
from iazar.generator.nonce_generator import NonceGenerator
from iazar.generator.paths import get_model_path
from iazar.utils.paths import get_nonce_training_data_path

logger = logging.getLogger("MLBasedGenerator")

class MLBasedGenerator(NonceGenerator):
    def __init__(self, config=None):
        super().__init__(config)
        self.model = None
        self.model_path = get_model_path("rf_nonce_model.joblib")
        self.fallback_enabled = self.ia_config.get('ml_fallback', True)
        self.load_model()

    def load_model(self):
        try:
            if os.path.exists(self.model_path):
                self.model = joblib.load(self.model_path)
                logger.info(f"✅ Modelo cargado: {self.model_path}")
            else:
                self.train_model()
        except Exception as e:
            logger.error(f"❌ Error cargando modelo: {e}")
            self.train_model()

    def train_model(self):
        logger.info("⚙️ Entrenando nuevo modelo...")
        try:
            training_data_path = get_nonce_training_data_path()
            if not os.path.exists(training_data_path):
                raise FileNotFoundError("No hay datos de entrenamiento")
            df = pd.read_csv(training_data_path)
            if len(df) < 100:
                raise ValueError("Datos insuficientes para entrenamiento (min 100)")
            X = df[['nonce']].values
            y = df['nonce']
            self.model = RandomForestRegressor(
                n_estimators=200,
                max_depth=16,
                random_state=42,
                n_jobs=-1
            )
            self.model.fit(X, y)
            joblib.dump(self.model, self.model_path)
            logger.info(f"✅ Modelo entrenado y guardado: {self.model_path}")
        except Exception as e:
            logger.error(f"❌ Error entrenando modelo: {e}")
            self.model = None

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000
        if not self.model:
            return self.fallback_generation(count)
        try:
            stats = self.get_stats()
            # Genera valores normales en el rango de los nonces históricos
            base_nonces = np.random.normal(stats['mean'], stats['std'], count)
            preds = self.model.predict(base_nonces.reshape(-1, 1)).astype(np.uint32)
            # Clip para evitar nonces negativos o fuera de rango uint32
            preds = np.clip(preds, 0, 2**32 - 1)
            return preds.tolist()
        except Exception as e:
            logger.error(f"❌ Error en predicción: {e}")
            return self.fallback_generation(count)

    def fallback_generation(self, count):
        if self.fallback_enabled:
            logger.warning("⚠️ Usando generador de respaldo")
            return super().generate(count)
        raise RuntimeError("Modelo no disponible y fallback deshabilitado")

    def get_stats(self):
        # Usa datos históricos si existen, si no, valores por defecto seguros
        if hasattr(self, 'nonces') and self.nonces:
            arr = np.array(self.nonces)
            return {'mean': np.mean(arr), 'std': max(np.std(arr), 1)}
        # Valores por defecto para el rango de nonces
        return {'mean': 2**31, 'std': 2**30}
