from iazar.generator.nonce_generator import NonceGenerator
from iazar.generator.range_based_generator import RangeBasedGenerator
from iazar.generator.random_generator import RandomGenerator
from iazar.generator.sequence_based_generator import SequenceBasedGenerator
from iazar.generator.adaptive_generator import AdaptiveGenerator
from iazar.generator.entropy_based_generator import EntropyBasedGenerator
from iazar.generator.ml_based_generator import MLBasedGenerator

import random

class HybridGenerator(NonceGenerator):
    def __init__(self, config=None):
        super().__init__(config)
        self.range_generator = RangeBasedGenerator(self.ia_config)
        self.random_generator = RandomGenerator(self.ia_config)
        self.sequence_generator = SequenceBasedGenerator(self.ia_config)
        self.adaptive_generator = AdaptiveGenerator(self.ia_config)
        self.entropy_generator = EntropyBasedGenerator(self.ia_config)
        self.ml_generator = MLBasedGenerator(self.ia_config)

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000

        generators = [
            self.range_generator,
            self.random_generator,
            self.sequence_generator,
            self.adaptive_generator,
            self.entropy_generator,
            self.ml_generator,
        ]
        results = []
        chunk = max(1, count // len(generators))
        for i, generator in enumerate(generators):
            if i == len(generators) - 1:
                # Garantiza cubrir la cantidad total solicitada (maneja redondeos)
                results.extend(generator.generate(count - len(results)))
            else:
                results.extend(generator.generate(chunk))
        random.shuffle(results)
        return results[:count]
