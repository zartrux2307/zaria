import os
import sys
import json
import time
import logging
import struct
import threading
import multiprocessing.shared_memory as shm

from iazar.generator.adaptive_generator import AdaptiveGenerator
from iazar.generator.entropy_based_generator import EntropyBasedGenerator
from iazar.generator.hybrid_generator import HybridGenerator
from iazar.generator.ml_based_generator import MLBasedGenerator
from iazar.generator.nonce_generator import NonceGenerator
from iazar.generator.random_generator import RandomGenerator
from iazar.generator.range_based_generator import RangeBasedGenerator
from iazar.generator.sequence_based_generator import SequenceBasedGenerator

# === CONFIGURACIÓN ===

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "global_config.json")
CONFIG_PATH = os.path.abspath(CONFIG_PATH)

with open(CONFIG_PATH, encoding="utf-8") as f:
    config = json.load(f)

PREFIX = str(config.get("prefix", "5555"))
BUFFER_SIZE = int(config.get("size", 4096))
PROXY_HOST = config.get("ia", {}).get("proxy_host", "127.0.0.1")
PROXY_PORT = config.get("ia", {}).get("proxy_port", 5555)
JOB_STRUCT_SIZE = 180
SOLUTION_STRUCT_SIZE = 73
SHM_JOB_SIZE = JOB_STRUCT_SIZE + 1
SHM_SOLUTION_SIZE = SOLUTION_STRUCT_SIZE + 1

# === LOGGING ===

logger = logging.getLogger("NonceOrchestrator")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
logger.addHandler(ch)

# === MEMORIA COMPARTIDA ===

job_shm = shm.SharedMemory(name=f"{PREFIX}_job")
solution_shm = shm.SharedMemory(name=f"{PREFIX}_solution")

# === FUNCIONES AUXILIARES ===

def deserialize_job(data: bytes) -> dict:
    try:
        blob = data[0:84].hex()
        target = hex(struct.unpack(">Q", data[84:92])[0])[2:]
        seed_hash = data[92:124].hex()
        job_id = data[124:160].decode("utf-8").rstrip("\0")
        height = struct.unpack(">I", data[160:164])[0]
        algo = data[164:180].decode("utf-8").rstrip("\0")
        return {
            "blob": blob,
            "target": target,
            "seed_hash": seed_hash,
            "job_id": job_id,
            "height": height,
            "algo": algo
        }
    except Exception as e:
        logger.error(f"Error deserializando job: {e}")
        return {}

def serialize_solution(sol: dict) -> bytes:
    try:
        job_id_bytes = sol["job_id"].encode("utf-8")[:36].ljust(36, b'\0')
        nonce_bytes = struct.pack(">I", sol["nonce"])
        hash_bytes = bytes.fromhex(sol["hash"])[:32].ljust(32, b'\0')
        is_valid = b"\x01" if sol.get("is_valid", True) else b"\x00"
        return job_id_bytes + nonce_bytes + hash_bytes + is_valid
    except Exception as e:
        logger.error(f"Error serializando solution: {e}")
        return b''

# === GENERADOR DE NONCES PRINCIPAL ===

class NonceOrchestrator:
    def __init__(self):
        self.last_job_id = None
        self.generators = []
        self.job_lock = threading.Lock()
        self.stop_event = threading.Event()
        self._init_generators()
        logger.info("🎯 Generadores básicos activos: %d", len(self.generators))

    def _init_generators(self):
        self.generators.append(HybridGenerator())
        self.generators.append(AdaptiveGenerator())
        self.generators.append(MLBasedGenerator())
        self.generators.append(EntropyBasedGenerator())
        self.generators.append(RandomGenerator())
        self.generators.append(RangeBasedGenerator())
        self.generators.append(SequenceBasedGenerator())

    def get_latest_job(self):
        if job_shm.buf[SHM_JOB_SIZE - 1] == 1:
            data = bytes(job_shm.buf[:JOB_STRUCT_SIZE])
            job_shm.buf[SHM_JOB_SIZE - 1] = 0
            return deserialize_job(data)
        return None

    def send_solution(self, solution):
        if not solution:
            return
        while solution_shm.buf[SHM_SOLUTION_SIZE - 1] == 1:
            time.sleep(0.001)
        sol_bytes = serialize_solution(solution)
        if len(sol_bytes) == SOLUTION_STRUCT_SIZE:
            solution_shm.buf[:SOLUTION_STRUCT_SIZE] = sol_bytes
            solution_shm.buf[SHM_SOLUTION_SIZE - 1] = 1
            logger.info(f"✅ Solución enviada: nonce={solution['nonce']} hash={solution['hash'][:12]}... job_id={solution['job_id']}")
        else:
            logger.error("Tamaño incorrecto de solución serializada")

    def mining_loop(self):
        logger.info("⏳ Esperando primer job_id...")
        while not self.stop_event.is_set():
            job = self.get_latest_job()
            if job and job["job_id"] != self.last_job_id:
                logger.info(f"🆕 Nuevo trabajo recibido: {job['job_id']} height={job['height']}")
                self.last_job_id = job["job_id"]
                threads = []
                for gen in self.generators:
                    t = threading.Thread(target=self.run_generator, args=(gen, job))
                    t.start()
                    threads.append(t)
            time.sleep(0.1)

    def run_generator(self, generator, job):
        try:
            # Cada generador debe implementar .generate(job), que retorna una solución o lista de soluciones
            res = generator.generate(job)
            if isinstance(res, dict):
                self.send_solution(res)
            elif isinstance(res, list):
                for sol in res:
                    self.send_solution(sol)
        except Exception as e:
            logger.error(f"Error ejecutando generador {generator.__class__.__name__}: {e}")

    def stop(self):
        self.stop_event.set()
        job_shm.close()
        solution_shm.close()

if __name__ == "__main__":
    orchestrator = NonceOrchestrator()
    try:
        orchestrator.mining_loop()
    except KeyboardInterrupt:
        logger.info("⛔ Orchestrator detenido por usuario.")
        orchestrator.stop()
        sys.exit(0)
