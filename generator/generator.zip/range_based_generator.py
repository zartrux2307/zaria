import os
import json
import random
import logging
from collections import defaultdict
from iazar.utils.paths import get_nonce_training_data_path

logger = logging.getLogger("RangeBasedGenerator")

class RangeBasedGenerator:
    def __init__(self, config=None):
        self.config = config or {}
        self.ranges = []
        self.weights = []
        self.num_ranges = self.config.get("num_ranges", 10)
        self._init_statistical_ranges()
        logger.info("✅ Generador basado en rangos inicializado PRO")

    def _init_statistical_ranges(self):
        """
        Lee los nonces históricos y calcula rangos y pesos basados en frecuencia.
        Permite rango dinámico y distribución ponderada.
        """
        try:
            data_path = get_nonce_training_data_path()
            if not os.path.exists(data_path):
                logger.warning(f"⚠️ Archivo de datos no encontrado: {data_path}")
                # Si no hay datos, usa 1 solo rango todo el espacio
                self.ranges = [(0, 2**32 - 1)]
                self.weights = [1.0]
                return

            counts = [0 for _ in range(self.num_ranges)]
            min_nonce = 0
            max_nonce = 2**32 - 1
            total = 0

            # Leer datos históricos
            with open(data_path, encoding="utf-8") as f:
                lines = [l.strip() for l in f if l.strip() and l.strip().isdigit()]
                nonces = [int(l) for l in lines]

            if len(nonces) == 0:
                self.ranges = [(0, 2**32 - 1)]
                self.weights = [1.0]
                return

            range_size = (max_nonce - min_nonce + 1) // self.num_ranges
            self.ranges = [
                (min_nonce + i * range_size, min_nonce + (i + 1) * range_size - 1)
                for i in range(self.num_ranges)
            ]
            self.ranges[-1] = (self.ranges[-1][0], max_nonce)  # Corrige último rango

            # Conteo de frecuencias por rango
            for n in nonces:
                idx = min((n - min_nonce) // range_size, self.num_ranges - 1)
                counts[idx] += 1
                total += 1

            if total == 0:
                self.weights = [1.0 / self.num_ranges] * self.num_ranges
            else:
                self.weights = [c / total for c in counts]

        except Exception as e:
            logger.error(f"❌ Error inicializando rangos: {str(e)}")
            self.ranges = [(0, 2**32 - 1)]
            self.weights = [1.0]

    def generate(self, count):
        """
        Genera nonces distribuidos según rangos y pesos históricos.
        """
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000

        if not self.ranges or not self.weights:
            self._init_statistical_ranges()

        nonces = []
        # Elige rangos de forma ponderada
        for _ in range(count):
            rango_idx = random.choices(range(len(self.ranges)), weights=self.weights, k=1)[0]
            start, end = self.ranges[rango_idx]
            nonce = random.randint(start, end)
            nonces.append(nonce)
        return nonces

    def info(self):
        """
        Devuelve información de los rangos y pesos usados para análisis/monitoring.
        """
        return [
            {
                "range": (start, end),
                "weight": weight
            }
            for (start, end), weight in zip(self.ranges, self.weights)
        ]
