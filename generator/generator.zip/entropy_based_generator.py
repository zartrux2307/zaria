import random
import numpy as np
from iazar.generator.nonce_generator import NonceGenerator
from iazar.analytics.entropy_tools import EntropyTools

class EntropyBasedGenerator(NonceGenerator):
    def __init__(self, config=None):
        super().__init__(config)
        self.quality_thresholds = {
            'min_entropy': self.ia_config.get('min_entropy', 3.5),
            'min_uniqueness': self.ia_config.get('min_uniqueness', 0.8),
            'max_zero_density': self.ia_config.get('max_zero_density', 0.7),
            'min_pattern_score': self.ia_config.get('min_pattern_score', 0.8)
        }
        # Ajusta automáticamente thresholds si hay suficientes datos históricos
        if self.nonces and len(self.nonces) >= 100:
            self.calcular_umbrales_automaticos()

    def calcular_umbrales_automaticos(self):
        features = {'entropy': [], 'uniqueness': [], 'zero_density': []}
        for nonce in random.sample(self.nonces, min(1000, len(self.nonces))):
            nonce_bytes = nonce.to_bytes(4, 'big')
            analysis = EntropyTools.analyze_nonce_quality(nonce_bytes)
            for key in features:
                if key in analysis:
                    features[key].append(analysis[key])
        self.quality_thresholds['min_entropy'] = np.percentile(features['entropy'], 25) if features['entropy'] else 3.5
        self.quality_thresholds['min_uniqueness'] = np.percentile(features['uniqueness'], 25) if features['uniqueness'] else 0.8
        self.quality_thresholds['max_zero_density'] = np.percentile(features['zero_density'], 75) if features['zero_density'] else 0.7

    def is_nonce_valid(self, candidate_bytes):
        features = EntropyTools.analyze_nonce_quality(candidate_bytes)
        return all([
            features.get('entropy', 0) >= self.quality_thresholds['min_entropy'],
            features.get('uniqueness', 0) >= self.quality_thresholds['min_uniqueness'],
            features.get('zero_density', 1) <= self.quality_thresholds['max_zero_density'],
            features.get('pattern_score', 0) >= self.quality_thresholds['min_pattern_score'],
            features.get('is_valid', False)
        ])

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000
        valid_nonces = []
        max_attempts = count * 10
        while len(valid_nonces) < count and max_attempts > 0:
            candidate = random.getrandbits(32)
            if self.is_nonce_valid(candidate.to_bytes(4, 'big')):
                valid_nonces.append(candidate)
            max_attempts -= 1
        if len(valid_nonces) < count:
            # fallback: llena con el método base (aleatorio normal)
            valid_nonces.extend(super().generate(count - len(valid_nonces)))
        return valid_nonces
