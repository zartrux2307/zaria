import csv
import time
import random
import numpy as np
from collections import defaultdict
from datetime import datetime
from iazar.utils.paths import get_nonce_training_data_path

class NonceGenerator:
    def __init__(self, config=None):
        self.config = config or {}
        self.ia_config = self.config.get('ia', {})
        self.data_path = get_nonce_training_data_path()
        self.max_nonce = self.ia_config.get('max_nonce', 2**32 - 1)
        self.num_rangos = self.ia_config.get('num_rangos', 10)
        self.top_rangos = self.ia_config.get('top_rangos', 3)
        self.rangos = []
        self.probabilidades = []
        self.top_rangos_list = []
        self.prob_normalizadas = []
        self.cargar_datos()
        self.calcular_probabilidades()
        self.seleccionar_top_rangos()

    def cargar_datos(self):
        """Carga todos los nonces del archivo CSV"""
        self.nonces = []
        try:
            with open(self.data_path, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    try:
                        nonce = int(row['nonce'])
                        if 0 <= nonce <= self.max_nonce:
                            self.nonces.append(nonce)
                    except (ValueError, KeyError):
                        continue
            print(f"✅ Cargados {len(self.nonces)} nonces de {self.data_path}")
        except FileNotFoundError:
            print(f"❌ Error: Archivo {self.data_path} no encontrado")
            self.nonces = [random.randint(0, self.max_nonce) for _ in range(1000)]
            print("⚠️ Usando datos de muestra generados aleatoriamente")

    def calcular_probabilidades(self):
        """Calcula las probabilidades por rango"""
        if not self.nonces:
            self.establecer_rangos_predeterminados()
            return

        # Crear rangos
        tamano_rango = self.max_nonce // self.num_rangos
        self.rangos = [
            (i * tamano_rango, (i + 1) * tamano_rango - 1) 
            for i in range(self.num_rangos)
        ]

        # Ajustar el último rango para incluir el máximo
        self.rangos[-1] = (self.rangos[-1][0], self.max_nonce)

        # Contar apariciones en cada rango
        conteos = [0] * self.num_rangos
        for nonce in self.nonces:
            for i, (inicio, fin) in enumerate(self.rangos):
                if inicio <= nonce <= fin:
                    conteos[i] += 1
                    break

        # Calcular probabilidades
        total = sum(conteos)
        self.probabilidades = [count / total if total > 0 else 0 for count in conteos]

        # Imprimir estadísticas
        print("\n📊 Estadísticas de rangos:")
        for i, ((inicio, fin), prob) in enumerate(zip(self.rangos, self.probabilidades)):
            print(f"Rango {i+1}: {inicio:,} - {fin:,} | Prob: {prob*100:.2f}%")

    def establecer_rangos_predeterminados(self):
        print("⚠️ Usando rangos predeterminados por falta de datos")
        tamano_rango = self.max_nonce // self.num_rangos
        self.rangos = [
            (i * tamano_rango, (i + 1) * tamano_rango - 1) 
            for i in range(self.num_rangos)
        ]
        self.rangos[-1] = (self.rangos[-1][0], self.max_nonce)
        self.probabilidades = [1/self.num_rangos] * self.num_rangos

    def seleccionar_top_rangos(self):
        """Selecciona los rangos con mayor probabilidad"""
        indices_ordenados = np.argsort(self.probabilidades)[::-1]  # De mayor a menor
        self.top_rangos_list = [self.rangos[i] for i in indices_ordenados[:self.top_rangos]]

        # Calcular probabilidades normalizadas para los top rangos
        prob_total_top = sum(self.probabilidades[i] for i in indices_ordenados[:self.top_rangos])
        self.prob_normalizadas = [self.probabilidades[i] / prob_total_top for i in indices_ordenados[:self.top_rangos]]

        print("\n🎯 Rangos seleccionados:")
        for i, (inicio, fin) in enumerate(self.top_rangos_list):
            print(f"Top {i+1}: {inicio:,} - {fin:,} | Prob: {self.prob_normalizadas[i]*100:.2f}%")

    def generar_nonce(self):
        """Genera un nonce de los rangos prioritarios"""
        # Seleccionar un rango basado en probabilidad
        rango_idx = np.random.choice(len(self.top_rangos_list), p=self.prob_normalizadas)
        inicio, fin = self.top_rangos_list[rango_idx]

        # Generar nonce aleatorio dentro del rango
        return random.randint(inicio, fin)

    def generate(self, count):
        if isinstance(count, dict):
            count = count.get("count") or count.get("num_nonces") or 1000
        """Genera un lote de nonces (implementación base)"""
        return [self.generar_nonce() for _ in range(count)]
