"""
randomx_validator.py
--------------------
Validador RandomX REAL para minería Monero (CPU).

Características:
- Carga robusta de la DLL RandomX (ruta fija o búsqueda incremental).
- Cache + Dataset (FULL_MEM opcional) reutilizables por seed hash.
- VM por thread (thread-local) para evitar contención.
- Re-hash dinámico cuando cambia el seed hash.
- Circuit breaker en fallos de inicialización.
- validate(nonce, block_data, return_hash=False) -> bool | (bool, hash_bytes)
- Conversión difficulty -> target si no se pasa target.
- Preparado para integrarse con orquestador y generadores adaptativos.

Config (sección "randomx" en global_config.json) ejemplo:
{
  "dll_path": "C:/zarturxia/src/libs/randomx.dll",
  "use_large_pages": true,
  "use_jit": true,
  "use_full_mem": true,
  "use_hard_aes": true,
  "secure_mode": false,
  "nonce_offset": 39,
  "breaker_fail_threshold": 5,
  "breaker_reset_seconds": 60
}
"""

from __future__ import annotations
import os
import sys
import ctypes
import threading
import logging
import atexit
import time
from typing import Optional, Dict, Tuple

# ---------------- Logging ----------------
LOGGER_NAME = "generator.randomx_validator"
logger = logging.getLogger(LOGGER_NAME)
if not logger.hasHandlers():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

# ---------------- Flags (bitmask) ----------------
RANDOMX_FLAG_DEFAULT     = 0
RANDOMX_FLAG_LARGE_PAGES = 1
RANDOMX_FLAG_JIT         = 2
RANDOMX_FLAG_FULL_MEM    = 4
RANDOMX_FLAG_HARD_AES    = 8
RANDOMX_FLAG_SECURE      = 16

HASH_SIZE = 32  # 256-bit
UINT32_MASK = 0xFFFFFFFF

# ---------------- Exceptions ----------------
class RandomXError(RuntimeError):
    pass

class RandomXInitError(RandomXError):
    pass

class RandomXSeedError(RandomXError):
    pass

class RandomXValidationError(RandomXError):
    pass

# ---------------- Helpers ----------------
def difficulty_to_target(difficulty: int) -> int:
    if difficulty <= 0:
        # Target máximo => acepta todo (fallback)
        return (1 << 256) - 1
    return ((1 << 256) - 1) // difficulty

def _int_from_hash_le(h: bytes) -> int:
    return int.from_bytes(h, "little")

# ---------------- Circuit Breaker ----------------
class CircuitBreaker:
    def __init__(self, fail_threshold: int, reset_seconds: int):
        self.fail_threshold = fail_threshold
        self.reset_seconds = reset_seconds
        self.fail_count = 0
        self.open_until = 0.0
        self._lock = threading.Lock()

    def allow(self) -> bool:
        with self._lock:
            if time.time() >= self.open_until:
                return True
            return False

    def success(self):
        with self._lock:
            self.fail_count = 0
            self.open_until = 0.0

    def failure(self):
        with self._lock:
            self.fail_count += 1
            if self.fail_count >= self.fail_threshold:
                self.open_until = time.time() + self.reset_seconds
                logger.error("[RandomX] Circuit breaker OPEN (failures=%d)", self.fail_count)

# ---------------- RandomX Core Wrapper ----------------
class _RandomXCore:
    """
    Encapsula cache/dataset y creación de VMs para un seed específico.
    Un _RandomXCore por seed_hash activo.
    """
    __slots__ = ("seed_hash", "cache", "dataset", "flags", "lib", "full_mem", "vm_local")

    def __init__(self, seed_hash: str, lib, flags: int, full_mem: bool):
        self.seed_hash = seed_hash
        self.lib = lib
        self.flags = flags
        self.full_mem = full_mem
        self.cache = None
        self.dataset = None
        self.vm_local = threading.local()
        self._init_seed()

    def _init_seed(self):
        # cache
        self.cache = self.lib.randomx_alloc_cache(self.flags)
        if not self.cache:
            raise RandomXInitError("randomx_alloc_cache failed")
        seed_bytes = bytes.fromhex(self.seed_hash)
        key_buf = (ctypes.c_ubyte * len(seed_bytes)).from_buffer_copy(seed_bytes)
        self.lib.randomx_init_cache(self.cache, key_buf, len(seed_bytes))
        # dataset opcional
        if self.full_mem:
            self.dataset = self.lib.randomx_alloc_dataset(self.flags)
            if not self.dataset:
                raise RandomXInitError("randomx_alloc_dataset failed")
            item_count = self.lib.randomx_dataset_item_count()
            self.lib.randomx_init_dataset(self.dataset, self.cache, 0, item_count)

    def _create_vm(self):
        vm = self.lib.randomx_create_vm(self.flags, self.cache, self.dataset if self.full_mem else None)
        if not vm:
            raise RandomXInitError("randomx_create_vm failed")
        return vm

    def get_thread_vm(self):
        vm = getattr(self.vm_local, "vm", None)
        if vm:
            return vm
        vm = self._create_vm()
        self.vm_local.vm = vm
        return vm

    def hash(self, input_bytes: bytes) -> bytes:
        vm = self.get_thread_vm()
        out_buf = (ctypes.c_ubyte * HASH_SIZE)()
        in_buf = (ctypes.c_ubyte * len(input_bytes)).from_buffer_copy(input_bytes)
        self.lib.randomx_calculate_hash(vm, in_buf, len(input_bytes), out_buf)
        return bytes(out_buf)

    def destroy(self):
        # Destroy VM(s)
        vm = getattr(self.vm_local, "vm", None)
        if vm:
            try:
                self.lib.randomx_destroy_vm(vm)
            except Exception:
                pass
            self.vm_local.vm = None
        # Release dataset
        if self.dataset:
            try:
                self.lib.randomx_release_dataset(self.dataset)
            except Exception:
                pass
            self.dataset = None
        # Release cache
        if self.cache:
            try:
                self.lib.randomx_release_cache(self.cache)
            except Exception:
                pass
            self.cache = None

# ---------------- RandomXValidator ----------------
class RandomXValidator:
    """
    Uso:
        validator = RandomXValidator(config)
        ok = validator.validate(nonce, block_data)
        ok, hash_bytes = validator.validate(nonce, block_data, return_hash=True)

    Donde block_data incluye:
        seed / seed_hash: str (64 hex)
        blob: bytes (block template)
        nonce_offset: int (posición del nonce dentro del blob)
        target (opcional): int 256-bit
        difficulty (opcional): int
    """
    def __init__(self, config: Optional[Dict] = None):
        self.cfg = config or {}
        self.dll_path = self._resolve_dll()
        self.flags = self._build_flags()
        self.lib = self._load_library()
        self._bind()
        self.full_mem = bool(self.cfg.get("use_full_mem", False))
        self.default_nonce_offset = int(self.cfg.get("nonce_offset", 39))

        # Seed cores (LRU limitado opcional)
        self._cores: Dict[str, _RandomXCore] = {}
        self._cores_lock = threading.RLock()
        self.max_seeds = int(self.cfg.get("max_seeds", 8))

        # Circuit breaker
        self.breaker = CircuitBreaker(
            fail_threshold=int(self.cfg.get("breaker_fail_threshold", 5)),
            reset_seconds=int(self.cfg.get("breaker_reset_seconds", 60))
        )

        atexit.register(self.close)
        logger.info("[RandomXValidator] Initialized dll=%s flags=0x%X full_mem=%s",
                    self.dll_path, self.flags, self.full_mem)

    # ---------- Public ----------
    def validate(self, nonce: int, block_data: Dict, return_hash: bool = False):
        if not self.breaker.allow():
            # Circuit OPEN: no intentamos real => devolvemos False directo
            return (False, b"\x00"*32) if return_hash else False

        try:
            seed_hex = block_data.get("seed") or block_data.get("seed_hash")
            if not seed_hex or len(seed_hex) != 64:
                raise RandomXSeedError("Missing or invalid seed hash (64 hex chars required)")

            blob = block_data.get("blob")
            if not isinstance(blob, (bytes, bytearray)):
                raise RandomXValidationError("Block data missing 'blob' bytes")

            nonce_offset = int(block_data.get("nonce_offset", self.default_nonce_offset))
            if nonce_offset < 0 or nonce_offset + 4 > len(blob):
                raise RandomXValidationError(f"Invalid nonce_offset={nonce_offset} for blob length={len(blob)}")

            target = block_data.get("target")
            if not isinstance(target, int):
                difficulty = block_data.get("difficulty", None)
                target = difficulty_to_target(int(difficulty)) if difficulty else ((1 << 256) - 1)

            nonce &= UINT32_MASK
            core = self._core_for_seed(seed_hex)
            # Mutar blob con nonce
            b = bytearray(blob)
            b[nonce_offset:nonce_offset+4] = nonce.to_bytes(4, "little")
            h = core.hash(bytes(b))
            hv_int = _int_from_hash_le(h)
            ok = hv_int < target
            if ok:
                self.breaker.success()
            else:
                # no cuenta como fallo "sistémico"
                pass
            if return_hash:
                return ok, h
            return ok
        except Exception as e:
            logger.debug("Validation error: %s", e, exc_info=True)
            self.breaker.failure()
            if return_hash:
                return False, b"\x00"*32
            return False

    def close(self):
        with self._cores_lock:
            for c in self._cores.values():
                try:
                    c.destroy()
                except Exception:
                    pass
            self._cores.clear()

    # ---------- Internals ----------
    def _resolve_dll(self) -> str:
        cand = self.cfg.get("dll_path")
        if cand and os.path.exists(cand):
            return cand
        base = os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar")
        candidates = [
            os.path.join(base, "src", "libs", "randomx.dll"),
            os.path.join(base, "libs", "randomx.dll"),
            "randomx.dll",
            "librandomx.so",
            "librandomx.dylib"
        ]
        for c in candidates:
            if os.path.exists(c):
                return c
        raise RandomXInitError(f"RandomX DLL not found in candidates (searched: {candidates})")

    def _build_flags(self) -> int:
        f = RANDOMX_FLAG_DEFAULT
        if self.cfg.get("use_large_pages", True): f |= RANDOMX_FLAG_LARGE_PAGES
        if self.cfg.get("use_jit", True):         f |= RANDOMX_FLAG_JIT
        if self.cfg.get("use_full_mem", False):   f |= RANDOMX_FLAG_FULL_MEM
        if self.cfg.get("use_hard_aes", True):    f |= RANDOMX_FLAG_HARD_AES
        if self.cfg.get("secure_mode", False):    f |= RANDOMX_FLAG_SECURE
        return f

    def _load_library(self):
        try:
            if os.name == "nt":
                return ctypes.WinDLL(self.dll_path)
            return ctypes.CDLL(self.dll_path)
        except Exception as e:
            raise RandomXInitError(f"Failed to load RandomX DLL: {e}") from e

    def _bind(self):
        L = self.lib
        # Pointers
        self.cache_p = ctypes.c_void_p
        self.dataset_p = ctypes.c_void_p
        self.vm_p = ctypes.c_void_p

        # Functions
        L.randomx_alloc_cache.restype = self.cache_p
        L.randomx_alloc_cache.argtypes = [ctypes.c_uint]

        L.randomx_init_cache.restype = None
        L.randomx_init_cache.argtypes = [self.cache_p, ctypes.c_void_p, ctypes.c_size_t]

        L.randomx_release_cache.restype = None
        L.randomx_release_cache.argtypes = [self.cache_p]

        L.randomx_alloc_dataset.restype = self.dataset_p
        L.randomx_alloc_dataset.argtypes = [ctypes.c_uint]

        L.randomx_dataset_item_count.restype = ctypes.c_uint64
        L.randomx_dataset_item_count.argtypes = []

        L.randomx_init_dataset.restype = None
        L.randomx_init_dataset.argtypes = [self.dataset_p, self.cache_p,
                                           ctypes.c_uint64, ctypes.c_uint64]

        L.randomx_release_dataset.restype = None
        L.randomx_release_dataset.argtypes = [self.dataset_p]

        L.randomx_create_vm.restype = self.vm_p
        L.randomx_create_vm.argtypes = [ctypes.c_uint, self.cache_p, self.dataset_p]

        L.randomx_destroy_vm.restype = None
        L.randomx_destroy_vm.argtypes = [self.vm_p]

        L.randomx_calculate_hash.restype = None
        L.randomx_calculate_hash.argtypes = [self.vm_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]

    def _core_for_seed(self, seed_hash: str) -> _RandomXCore:
        if len(seed_hash) != 64:
            raise RandomXSeedError("Seed hash must be 64 hex chars")
        with self._cores_lock:
            core = self._cores.get(seed_hash)
            if core:
                return core
            # LRU eviction simple
            if len(self._cores) >= self.max_seeds:
                # Evict oldest (insertion order preserved PY3.7+)
                evict_seed = next(iter(self._cores))
                ev = self._cores.pop(evict_seed)
                try:
                    ev.destroy()
                except Exception:
                    pass
            core = _RandomXCore(seed_hash, self.lib, self.flags, self.full_mem)
            self._cores[seed_hash] = core
            return core
