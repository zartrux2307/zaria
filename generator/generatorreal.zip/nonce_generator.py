from __future__ import annotations
"""
nonce_generator.py
------------------
BaseNonceGenerator + GroupedTopNonceGenerator (refactor producción).

Proporciona:
- Clase base con utilidades de métricas bitwise y aceptación.
- Generador "grouped" que divide el espacio uint32 en intervalos y aplica
  un esquema bandit (softmax + temperatura) para explorar/explotar.

Salida estándar de cada generador: lista de diccionarios con claves:
  ["nonce","entropy","uniqueness","zero_density","pattern_score","is_valid","block_height"]

Este archivo NO conoce detalles de RandomX; la validación concreta depende
de que se le inyecte un objeto `validator` con método:
    validate(nonce:int, block_data:dict) -> bool
o (bool, hash_bytes) si se extendiera en el futuro.

Se han añadido marcadores `# METRIC:` donde integrar instrumentación real.
"""

import os
import json
import math
import time
import logging
import threading
from pathlib import Path
from typing import Optional, Dict, List, Iterable, Any, Tuple, Callable

try:
    import numpy as np
    _HAS_NUMPY = True
except Exception:  # pragma: no cover
    np = None  # type: ignore
    _HAS_NUMPY = False

# ----------------------------------------------------------------------------------
# Constantes / Utilidades comunes
# ----------------------------------------------------------------------------------
CSV_FIELDS = ["nonce", "entropy", "uniqueness", "zero_density", "pattern_score", "is_valid", "block_height"]
UINT32_MASK = 0xFFFFFFFF
BIT_WIDTH = 32
LOGGER_BASE = "generator"


# ----------------------------------------------------------------------------------
# Loader de configuración centralizado (cache simple)
# ----------------------------------------------------------------------------------
class _ConfigCache:
    _lock = threading.Lock()
    _cache: Dict[str, Dict] = {}
    _mtimes: Dict[str, float] = {}

    @classmethod
    def load(cls, path: Path, force: bool = False) -> Dict:
        try:
            mtime = path.stat().st_mtime
        except FileNotFoundError:
            return {}
        p = str(path)
        with cls._lock:
            if (not force) and p in cls._cache and cls._mtimes.get(p) == mtime:
                return cls._cache[p]
            try:
                with path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                cls._cache[p] = data
                cls._mtimes[p] = mtime
                return data
            except Exception:
                return cls._cache.get(p, {})


# ----------------------------------------------------------------------------------
# Clase Base de Generadores
# ----------------------------------------------------------------------------------
class BaseNonceGenerator:
    """
    Clase base: define interfaz y utilidades.

    Subclases deben implementar:
        run_generation(block_height:int, block_data:dict, batch_size:int) -> List[dict]

    Config:
        - history_window (int) ventana para ratio de aceptación reciente.
    """
    name: str
    DEFAULTS: Dict[str, Any] = {}

    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None):
        self.name = name
        self.logger = logging.getLogger(f"{LOGGER_BASE}.{name}")
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            self.logger.addHandler(handler)
        self.logger.propagate = True

        base_dir = Path(os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        self.base_dir = base_dir
        self.config_path = base_dir / "config" / "global_config.json"
        global_cfg = _ConfigCache.load(self.config_path)

        section_key = f"{self.name}_generator"
        # Mezcla prioridad: config explícita > global_json
        section_cfg = (config or {}).get(section_key, {}) if config else global_cfg.get(section_key, {})
        merged = {**self.DEFAULTS, **section_cfg}
        self.config = merged

        self._lock = threading.RLock()
        self._accept_history: List[int] = []
        self._history_window = int(self.config.get("history_window", 500))
        self._last_generation_time = 0.0
        self.logger.debug("Initialized BaseNonceGenerator config=%s", self.config)

    # ---- API principal (abstract) ----
    def run_generation(
        self,
        block_height: int,
        block_data: Dict[str, Any],
        batch_size: int = 500
    ) -> Iterable[Dict[str, Any]]:  # pragma: no cover
        raise NotImplementedError

    # ---- Hooks sobrescribibles ----
    def _pre_generation(self, block_height: int, block_data: Dict[str, Any]):  # pragma: no cover
        pass

    def _post_generation(self, records: List[Dict[str, Any]]):  # pragma: no cover
        pass

    def _on_error(self, exc: Exception):
        self.logger.error("Error in generator %s: %s", self.name, exc, exc_info=True)

    # ---- Métricas bitwise (utilidades) ----
    @staticmethod
    def sanitize_uint32(v: int) -> int:
        return int(v) & UINT32_MASK

    @staticmethod
    def bit_entropy(n: int) -> float:
        b = f"{n:032b}"
        zeros = b.count('0')
        p0 = zeros / BIT_WIDTH
        if p0 == 0.0 or p0 == 1.0:
            return 0.0
        p1 = 1.0 - p0
        return -(p0 * math.log2(p0) + p1 * math.log2(p1))

    @staticmethod
    def zero_density(n: int) -> float:
        b = f"{n:032b}"
        return b.count('0') / BIT_WIDTH

    @staticmethod
    def pattern_score(n: int) -> float:
        b = f"{n:032b}"
        runs0 = b.split('1')
        runs1 = b.split('0')
        max_run = max(
            max((len(r) for r in runs0), default=0),
            max((len(r) for r in runs1), default=0)
        )
        penalty = min(0.6, max_run / BIT_WIDTH)
        return max(0.4, 1.0 - penalty)

    def uniqueness(self, n: int, recent: List[int]) -> float:
        """
        Uniqueness heurística basada en distancia Hamming media a últimos N nonces.
        """
        if not recent:
            return 1.0
        subset = recent[-32:]
        diffs = 0
        for r in subset:
            diffs += bin((r ^ n) & UINT32_MASK).count("1")
        return max(0.6, min(1.0, diffs / (BIT_WIDTH * len(subset))))

    # ---- Registro de aceptación ----
    def record_accept(self, accepted: bool):
        self._accept_history.append(1 if accepted else 0)
        if len(self._accept_history) > self._history_window:
            self._accept_history = self._accept_history[-self._history_window:]

    def recent_accept_ratio(self) -> float:
        if not self._accept_history:
            return 0.0
        return sum(self._accept_history) / len(self._accept_history)

    # ---- Extensiones vectorizadas (subclases pueden usar) ----
    @staticmethod
    def _compute_bit_metrics_vectorized(nonces: List[int]) -> Dict[str, List[float]]:
        """
        Devuelve dict con listas: entropy, zero_density, pattern_score
        Intento vectorizado con NumPy si disponible; fallback python puro.
        """
        if not nonces:
            return {"entropy": [], "zero_density": [], "pattern_score": []}

        if _HAS_NUMPY:
            arr = np.array(nonces, dtype=np.uint32)
            bits = np.unpackbits(arr.view(np.uint8)).reshape(-1, BIT_WIDTH)
            zeros = (bits == 0).sum(axis=1)
            p0 = zeros / BIT_WIDTH
            p1 = 1.0 - p0
            with np.errstate(divide='ignore', invalid='ignore'):
                entropy = -(p0 * np.log2(p0, where=(p0 > 0)) + p1 * np.log2(p1, where=(p1 > 0)))
                entropy = np.nan_to_num(entropy)
            transitions = np.diff(bits, axis=1) != 0
            run_lengths = BIT_WIDTH - transitions.sum(axis=1)
            run_penalty = np.clip(run_lengths / BIT_WIDTH, 0, 0.6)
            pattern_score = np.maximum(0.4, 1.0 - run_penalty)
            zero_density = p0
            return {
                "entropy": entropy.tolist(),
                "zero_density": zero_density.tolist(),
                "pattern_score": pattern_score.tolist()
            }

        # Fallback simple
        entropy_list: List[float] = []
        zero_list: List[float] = []
        pattern_list: List[float] = []
        for n in nonces:
            b = f"{n:032b}"
            zeros = b.count('0')
            p0 = zeros / BIT_WIDTH
            if p0 in (0.0, 1.0):
                ent = 0.0
            else:
                ent = -(p0 * math.log2(p0) + (1 - p0) * math.log2(1 - p0))
            runs0 = b.split('1')
            runs1 = b.split('0')
            max_run = max(
                max((len(r) for r in runs0), default=0),
                max((len(r) for r in runs1), default=0)
            )
            penalty = min(0.6, max_run / BIT_WIDTH)
            pattern = max(0.4, 1.0 - penalty)
            entropy_list.append(ent)
            zero_list.append(p0)
            pattern_list.append(pattern)
        return {
            "entropy": entropy_list,
            "zero_density": zero_list,
            "pattern_score": pattern_list
        }

    def _post_validation_record(self, record: Dict[str, Any], validation_result: Any):  # pragma: no cover
        """
        Hook para que subclases puedan enriquecer un registro con info adicional
        (por ejemplo hash si validator devuelve (bool, hash_bytes)).
        """
        if isinstance(validation_result, tuple) and len(validation_result) == 2:
            ok, h = validation_result
            if ok and isinstance(h, (bytes, bytearray)) and len(h) == 32:
                record["hash"] = h.hex()

    def close(self):  # pragma: no cover
        pass


# ----------------------------------------------------------------------------------
# GroupedTopNonceGenerator
# ----------------------------------------------------------------------------------
class GroupedTopNonceGenerator(BaseNonceGenerator):
    """
    Generador que divide el espacio uint32 en G grupos (bins) y ajusta probabilidad
    de muestreo de cada grupo en función de su ratio de éxito (bandit suave).

    Flujo:
      1. Softmax sobre ratios de aceptación por grupo (con temperatura).
      2. Asigna número de candidatos por grupo.
      3. Genera nonces uniformes dentro de cada intervalo.
      4. Calcula métricas bitwise (vectorizado si NumPy).
      5. Pre‑filtro por entropía / patrón.
      6. Validación opcional con validator inyectado.
      7. Ajusta contadores y registra aceptación.
    """

    DEFAULTS = {
        "groups": 16,
        "initial_weight": 1.0,
        "softmax_temperature": 1.5,
        "temperature_min": 0.5,
        "temperature_decay": 0.98,
        "batch_candidate_factor": 4,
        "max_candidate_factor": 32,
        "max_attempt_loops": 6,
        "min_entropy_threshold": 0.0,
        "pattern_score_min": 0.40,
        "recent_window": 2048,
        "use_validator": True
    }

    def __init__(self, config: Optional[Dict[str, Any]] = None, validator=None):
        super().__init__("grouped", config)
        self.validator = validator
        self.groups = max(2, int(self.config.get("groups", self.DEFAULTS["groups"])))
        span = (UINT32_MASK + 1) // self.groups
        self._ranges: List[Tuple[int, int]] = []
        start = 0
        for g in range(self.groups):
            end = start + span - 1 if g < self.groups - 1 else UINT32_MASK
            self._ranges.append((start, end))
            start = end + 1

        init_w = float(self.config.get("initial_weight", 1.0))
        self.accept_counters = [1] * self.groups
        self.total_counters = [1] * self.groups
        self.temperature = float(self.config.get("softmax_temperature", 1.5))
        self._recent_valid: List[int] = []
        self._recent_lock = threading.Lock()
        self._recent_limit = max(256, min(8192, int(self.config.get("recent_window", 2048))))

    # ---- API principal ----
    def run_generation(
        self,
        block_height: int,
        block_data: Dict[str, Any],
        batch_size: int = 500
    ) -> List[Dict[str, Any]]:
        t0 = time.perf_counter()
        records: List[Dict[str, Any]] = []
        factor = int(self.config.get("batch_candidate_factor", 4))
        max_factor = int(self.config.get("max_candidate_factor", 32))
        attempts = 0
        use_validator = bool(self.config.get("use_validator", True) and self.validator)

        self._pre_generation(block_height, block_data)

        while len(records) < batch_size and attempts < int(self.config.get("max_attempt_loops", 6)):
            target_candidates = batch_size * factor
            group_probs = self._softmax_weights()
            group_counts = self._allocate_counts(target_candidates, group_probs)
            candidates, candidate_groups = self._generate_candidates(group_counts)

            if not candidates:
                attempts += 1
                factor = min(factor * 2, max_factor)
                self._decay_temperature()
                continue

            metrics = self._compute_metrics(candidates)
            filtered_indices = self._prefilter_indices(metrics)
            if not filtered_indices:
                attempts += 1
                factor = min(factor * 2, max_factor)
                self._decay_temperature()
                continue

            # Validación / construcción de registros
            for idx in filtered_indices:
                nonce = candidates[idx]
                grp = candidate_groups[idx]
                validation_result: Any
                if use_validator:
                    try:
                        validation_result = self.validator.validate(nonce, block_data)
                    except Exception:
                        validation_result = False
                else:
                    validation_result = True  # sin validator ⇒ se delega al pipeline posterior

                if isinstance(validation_result, tuple):
                    is_valid = bool(validation_result[0])
                else:
                    is_valid = bool(validation_result)

                self.total_counters[grp] += 1
                if is_valid:
                    self.accept_counters[grp] += 1
                    self.record_accept(True)
                else:
                    self.record_accept(False)

                rec = {
                    "nonce": nonce,
                    "entropy": round(metrics["entropy"][idx], 5),
                    "uniqueness": round(metrics["uniqueness"][idx], 5),
                    "zero_density": round(metrics["zero_density"][idx], 5),
                    "pattern_score": round(metrics["pattern_score"][idx], 5),
                    "is_valid": bool(is_valid),
                    "block_height": block_height
                }
                self._post_validation_record(rec, validation_result)

                if is_valid:
                    self._record_recent(nonce)

                records.append(rec)
                if len(records) >= batch_size:
                    break

            attempts += 1
            if len(records) < batch_size:
                factor = min(factor * 2, max_factor)
            self._decay_temperature()

        elapsed = time.perf_counter() - t0
        self._post_generation(records)
        self.logger.info(
            "[GroupedGenerator] block=%s produced=%d attempts=%d factor_final=%d elapsed=%.3fs accept_ratio=%.4f",
            block_height, len(records), attempts, factor, elapsed, self.recent_accept_ratio()
        )
        # METRIC: grouped_generator_batch_latency.observe(elapsed)
        return records

    # ---- Internal helpers ----
    def _compute_metrics(self, nonces: List[int]) -> Dict[str, List[float]]:
        """
        Devuelve dict con listas alineadas al orden de 'nonces'.
        """
        bit_metrics = self._compute_bit_metrics_vectorized(nonces)
        recent = self._recent_snapshot()
        uniqueness: List[float] = []
        if _HAS_NUMPY and recent:
            arr = np.array(nonces, dtype=np.uint32)
            recent_arr = np.array(recent[-32:], dtype=np.uint32)
            # XOR y popcount vectorizado
            xor = arr[:, None] ^ recent_arr[None, :]
            pop = np.unpackbits(xor.view(np.uint8), axis=2).sum(axis=2)
            uniqueness = np.clip(pop.mean(axis=1) / BIT_WIDTH, 0.6, 1.0).tolist()
        else:
            for n in nonces:
                uniqueness.append(self.uniqueness(n, recent))
        return {
            "entropy": bit_metrics["entropy"],
            "zero_density": bit_metrics["zero_density"],
            "pattern_score": bit_metrics["pattern_score"],
            "uniqueness": uniqueness
        }

    def _prefilter_indices(self, metrics: Dict[str, List[float]]) -> List[int]:
        ent_min = float(self.config.get("min_entropy_threshold", 0.0))
        pat_min = float(self.config.get("pattern_score_min", 0.40))
        entropy = metrics["entropy"]
        pattern = metrics["pattern_score"]
        idx_out: List[int] = []
        for i in range(len(entropy)):
            if entropy[i] >= ent_min and pattern[i] >= pat_min:
                idx_out.append(i)
        return idx_out

    def _softmax_weights(self) -> List[float]:
        ratios = []
        for a, t in zip(self.accept_counters, self.total_counters):
            ratios.append(a / t if t else 0.0)
        mx = max(ratios) if ratios else 1.0
        temp_min = float(self.config.get("temperature_min", 0.5))
        temp = max(temp_min, self.temperature)
        exps = [math.exp((r - mx) / temp) for r in ratios]
        ssum = sum(exps)
        if ssum <= 0:
            return [1.0 / self.groups] * self.groups
        return [e / ssum for e in exps]

    def _allocate_counts(self, total: int, probs: List[float]) -> List[int]:
        counts = [0] * len(probs)
        remaining = total
        for i, p in enumerate(probs):
            c = int(p * total)
            counts[i] = c
            remaining -= c
        i = 0
        while remaining > 0 and counts:
            counts[i % len(counts)] += 1
            remaining -= 1
            i += 1
        return counts

    def _generate_candidates(self, group_counts: List[int]) -> Tuple[List[int], List[int]]:
        candidates: List[int] = []
        groups_meta: List[int] = []
        for gi, count in enumerate(group_counts):
            if count <= 0:
                continue
            lo, hi = self._ranges[gi]
            width = hi - lo + 1
            if _HAS_NUMPY:
                arr = (np.random.randint(0, width, size=count, dtype=np.uint32) + lo) & UINT32_MASK
                candidates.extend(int(x) for x in arr)
            else:
                import secrets
                for _ in range(count):
                    n = lo + (secrets.randbits(32) % width)
                    candidates.append(n & UINT32_MASK)
            groups_meta.extend([gi] * count)
        if _HAS_NUMPY and candidates:
            arr = np.array(candidates, dtype=np.uint32)
            uniq, idx_map = np.unique(arr, return_index=True)
            candidates = [int(x) for x in uniq]
            groups_meta = [groups_meta[i] for i in idx_map]
        return candidates, groups_meta

    def _decay_temperature(self):
        decay = float(self.config.get("temperature_decay", 0.98))
        min_temp = float(self.config.get("temperature_min", 0.5))
        self.temperature = max(min_temp, self.temperature * decay)

    def _record_recent(self, nonce: int):
        with self._recent_lock:
            self._recent_valid.append(nonce & UINT32_MASK)
            if len(self._recent_valid) > self._recent_limit:
                self._recent_valid = self._recent_valid[-self._recent_limit:]

    def _recent_snapshot(self) -> List[int]:
        with self._recent_lock:
            return list(self._recent_valid)

    def _post_generation(self, records: List[Dict[str, Any]]):
        # METRIC: grouped_generator_records.inc(len(records))
        pass

    # ---- Estadísticas / Diagnóstico ----
    def stats(self) -> Dict[str, Any]:
        ratios = [
            (a / t) if t else 0.0
            for a, t in zip(self.accept_counters, self.total_counters)
        ]
        return {
            "groups": self.groups,
            "temperature": round(self.temperature, 4),
            "ratios": ratios,
            "recent_accept_ratio": round(self.recent_accept_ratio(), 4),
            "recent_cache": len(self._recent_valid)
        }

    def reset_stats(self):
        self.accept_counters = [1] * self.groups
        self.total_counters = [1] * self.groups
        self._accept_history.clear()
        with self._recent_lock:
            self._recent_valid.clear()
        self.temperature = float(self.config.get("softmax_temperature", 1.5))

    def close(self):
        # Recursos explícitos (si hubiera) se liberarían aquí
        pass


# ----------------------------------------------------------------------------------
# Factory Helper
# ----------------------------------------------------------------------------------
def create_grouped_generator(config: Optional[Dict[str, Any]] = None, validator=None) -> GroupedTopNonceGenerator:
    """
    Factory externa para compatibilidad dinámica de importación.
    """
    return GroupedTopNonceGenerator(config=config, validator=validator)
