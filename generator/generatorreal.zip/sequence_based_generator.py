from __future__ import annotations
import os, time, math, logging, random
from pathlib import Path
from typing import Dict, Any, List, Optional

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

logger = logging.getLogger("generator.sequence")
UINT32_MASK = 0xFFFFFFFF
CSV_FIELDS = ["nonce","entropy","uniqueness","zero_density","pattern_score","is_valid","block_height"]

DEFAULT_SEQ_CONFIG = {
    "initial_weights": {"lcg": 0.4, "xorshift": 0.3, "pcg": 0.3},
    "min_entropy_batch": 4.5,
    "degeneration_threshold": 4.0,
    "weight_adjust_alpha": 0.05,
    "internal_factor": 3,
    "max_internal_factor": 6
}

class SequenceEngines:
    __slots__ = ("seed_lcg","seed_xor","seed_pcg")
    def __init__(self, seed: int):
        self.seed_lcg = (seed ^ 0xA5A5A5A5) & UINT32_MASK
        self.seed_xor = (seed ^ 0xC3C3C3C3) & UINT32_MASK
        self.seed_pcg = (seed ^ 0x9E3779B9) & UINT32_MASK

    def lcg(self) -> int:
        # Parámetros glibc modificados (32-bit)
        self.seed_lcg = (1103515245 * self.seed_lcg + 12345) & UINT32_MASK
        return self.seed_lcg

    def xorshift(self) -> int:
        x = self.seed_xor
        x ^= (x << 13) & UINT32_MASK
        x ^= (x >> 17)
        x ^= (x << 5) & UINT32_MASK
        self.seed_xor = x & UINT32_MASK
        return self.seed_xor

    def pcg32(self) -> int:
        state = self.seed_pcg
        state = (state * 6364136223846793005 + 1442695040888963407) & ((1 << 64) - 1)
        self.seed_pcg = state & UINT32_MASK
        xorshifted = (((state >> 18) ^ state) >> 27) & UINT32_MASK
        rot = (state >> 59) & 0x1F
        return ((xorshifted >> rot) | (xorshifted << ((-rot) & 31))) & UINT32_MASK

class AdaptiveWeights:
    def __init__(self, initial: Dict[str,float], alpha: float):
        s = sum(initial.values()) or 1.0
        self.weights = {k: v/s for k,v in initial.items()}
        self.alpha = alpha
        self.success_counts = {k: 1.0 for k in initial}
        self.total = sum(self.success_counts.values())

    def sample_counts(self, batch: int) -> Dict[str,int]:
        alloc = {}
        remaining = batch
        for i,(k,w) in enumerate(sorted(self.weights.items(), key=lambda kv: kv[1], reverse=True)):
            cnt = batch if i == len(self.weights)-1 else max(1, int(round(batch * w)))
            cnt = min(cnt, remaining)
            alloc[k] = cnt
            remaining -= cnt
        if remaining > 0:  # distribuir residuo
            for k in alloc:
                if remaining==0: break
                alloc[k]+=1; remaining-=1
        return alloc

    def update(self, contrib: Dict[str,int]):
        # Recompensa proporcional a contrib válidos
        total_new = sum(contrib.values()) or 1
        for k,v in contrib.items():
            reward = v / total_new
            self.success_counts[k] = (1 - self.alpha) * self.success_counts[k] + self.alpha * (1 + reward)
        tot = sum(self.success_counts.values())
        self.weights = {k: self.success_counts[k]/tot for k in self.success_counts}

class SequenceBasedGenerator:
    NAME = "sequence"
    def __init__(self, config: Optional[Dict[str,Any]] = None, base_dir: Optional[Path] = None):
        self.config = (config or {}).get("sequence", {})
        for k,v in DEFAULT_SEQ_CONFIG.items():
            self.config.setdefault(k,v)
        self.base_dir = Path(base_dir or os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        seed = int.from_bytes(os.urandom(8), "little") & UINT32_MASK
        self.engines = SequenceEngines(seed)
        self.weights = AdaptiveWeights(self.config["initial_weights"], self.config["weight_adjust_alpha"])
        self._rng = random.SystemRandom()
        self._degeneration_streak = 0
        logger.info("[sequence] Initialized with weights %s", self.weights.weights)

    # ---------------- Metrics -----------------
    def _entropy32(self, arr):
        if not np:
            out=[]
            for v in arr:
                ones = bin(v).count("1")
                p = ones/32.0
                if p in (0,1): out.append(0.0)
                else: out.append(-(p*math.log2(p)+(1-p)*math.log2(1-p)))
            return out
        a = np.asarray(arr, dtype=np.uint32)
        ones = np.unpackbits(a.view(np.uint8)).reshape(-1,32).sum(axis=1)
        p = np.clip(ones/32.0,1e-9,1-1e-9)
        return - (p*np.log2(p)+(1-p)*np.log2(1-p))

    def _zero_density(self, arr):
        if not np:
            return [(32 - bin(v).count("1"))/32.0 for v in arr]
        a = np.asarray(arr, dtype=np.uint32)
        ones = np.unpackbits(a.view(np.uint8)).reshape(-1,32).sum(axis=1)
        return (32 - ones)/32.0

    def _pattern_score(self, arr):
        if not np:
            scores=[]
            for v in arr:
                bits=f"{v:032b}"; repeats=sum(bits[i:i+4]==bits[i+4:i+8] for i in range(0,24,4))
                scores.append(max(0.0,1.0-repeats/8.0))
            return scores
        a=np.asarray(arr,dtype=np.uint32)
        b=a.view(np.uint8).reshape(-1,4)
        std=b.std(axis=1)
        return np.clip(std/74.0,0,1)

    def _uniqueness(self, arr):
        if not np:
            return [((v ^ (v<<13) ^ (v>>7) ^ (v<<3)) & UINT32_MASK)/UINT32_MASK for v in arr]
        a=np.asarray(arr,dtype=np.uint32)
        mix=(a ^ (a<<13) ^ (a>>7) ^ (a<<3)) & UINT32_MASK
        return mix.astype(np.float64)/UINT32_MASK

    # ---------------- Core engines -------------
    def _produce(self, engine: str, count: int) -> List[int]:
        if engine == "lcg":
            return [self.engines.lcg() for _ in range(count)]
        if engine == "xorshift":
            return [self.engines.xorshift() for _ in range(count)]
        if engine == "pcg":
            return [self.engines.pcg32() for _ in range(count)]
        # fallback random
        return [self._rng.getrandbits(32) for _ in range(count)]

    def _maybe_reseed(self):
        # Reseed suave si degeneración sostenida
        if self._degeneration_streak >= 5:
            new_seed = int.from_bytes(os.urandom(8),"little") & UINT32_MASK
            self.engines = SequenceEngines(new_seed)
            self._degeneration_streak = 0
            logger.info("[sequence] Reseeded engines")

    def run_generation(self, block_height: int, block_data: Dict[str, Any], batch_size: int = 500) -> List[Dict[str,Any]]:
        internal_factor = min(self.config.get("internal_factor",3), self.config.get("max_internal_factor",6))
        internal_target = batch_size * internal_factor
        alloc = self.weights.sample_counts(internal_target)
        raw: List[int] = []
        contrib_counts = {k:0 for k in alloc}
        for engine, cnt in alloc.items():
            seq = self._produce(engine, cnt)
            raw.extend(seq)
            contrib_counts[engine]+=len(seq)
        # Deduplicar intra-batch
        if np:
            arr = np.asarray(raw, dtype=np.uint32)
            _, idx = np.unique(arr, return_index=True)
            arr = arr[np.sort(idx)]
            raw = arr.tolist()
        else:
            raw = list(dict.fromkeys(raw))
        # Si falta para batch final, rellenar aleatorio
        while len(raw) < batch_size:
            raw.append(self._rng.getrandbits(32))
        raw = raw[:batch_size]
        entropy_vals = self._entropy32(raw)
        zero_density_vals = self._zero_density(raw)
        pattern_vals = self._pattern_score(raw)
        uniqueness_vals = self._uniqueness(raw)
        # Calidad media
        if np:
            avg_entropy = float(np.mean(entropy_vals))
        else:
            avg_entropy = sum(entropy_vals)/len(entropy_vals)
        if avg_entropy < self.config["degeneration_threshold"]:
            self._degeneration_streak += 1
        else:
            self._degeneration_streak = 0
        self._maybe_reseed()
        # Actualizar pesos (asumimos todos válidos por ahora; downstream filtrará)
        self.weights.update(contrib_counts)
        records: List[Dict[str,Any]] = []
        for i, nonce in enumerate(raw):
            records.append({
                "nonce": int(nonce) & UINT32_MASK,
                "entropy": float(entropy_vals[i]),
                "uniqueness": float(uniqueness_vals[i]),
                "zero_density": float(zero_density_vals[i]),
                "pattern_score": float(pattern_vals[i]),
                "is_valid": True,
                "block_height": int(block_height)
            })
        logger.debug("sequence batch=%d avg_entropy=%.3f weights=%s", len(records), avg_entropy, self.weights.weights)
        return records

# Registro para autodescubrimiento
GENERATORS = {SequenceBasedGenerator.NAME: SequenceBasedGenerator}
