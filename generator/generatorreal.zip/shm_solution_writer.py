# shm_solution_writer.py
from __future__ import annotations
import multiprocessing.shared_memory as shm
import struct
import time

SOLUTION_STRUCT_SIZE = 73
FLAG_INDEX = SOLUTION_STRUCT_SIZE  # 73 -> index 73 (size + 1 reserved)

class SharedMemorySolutionWriter:
    def __init__(self, prefix: str = "5555"):
        self.prefix = prefix
        self.solution_shm = None
        self._open()

    def _open(self):
        name = f"{self.prefix}_solution"
        self.solution_shm = shm.SharedMemory(name=name)

    def try_submit(self, job_id: str, nonce: int, hash_bytes: bytes, is_valid: bool) -> bool:
        if self.solution_shm is None:
            return False
        buf = self.solution_shm.buf
        # Si flag ocupado espera un poquito
        if buf[SOLUTION_STRUCT_SIZE] == 1:
            return False
        if len(hash_bytes) != 32:
            return False
        job_bytes = job_id.encode('utf-8')[:36].ljust(36, b'\0')
        nonce_bytes = struct.pack(">I", nonce & 0xFFFFFFFF)
        rec = job_bytes + nonce_bytes + hash_bytes + (b'\x01' if is_valid else b'\x00')
        if len(rec) != SOLUTION_STRUCT_SIZE:
            return False
        buf[:SOLUTION_STRUCT_SIZE] = rec
        buf[SOLUTION_STRUCT_SIZE] = 1
        return True
