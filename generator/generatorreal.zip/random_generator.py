# ================= Random Generator (Refactor Completo) ==================
# Archivo: random_generator.py
# Objetivo: Generador aleatorio uniforme robusto y de alto rendimiento para RandomX.
# Mejores prácticas:
# - Sanitización 32-bit temprana (evita rechazos posteriores).
# - Generación vectorizada y desduplicación.
# - Métricas bitwise vectorizadas (sin bucles Python intensivos) con fallback puro Python.
# - Validación RandomX concurrente con pool persistente.
# - Backoff adaptativo y límites de intentos.
# - Hooks de métricas centralizados (# METRIC: ...).
# - Registro estructurado y control de verbosidad.
# - Resiliencia: circuit breaker delegando al validator.
# - Thread safety sin lock global prolongado (lock sólo para actualización de cache de recientes y training_data).

from __future__ import annotations
import os
import time
import csv
import logging
import threading
from pathlib import Path
from typing import Optional, Dict, List

try:
    import numpy as np
    _HAS_NUMPY = True
except Exception:  # pragma: no cover
    np = None  # type: ignore
    _HAS_NUMPY = False

from iazar.generator.nonce_generator import BaseNonceGenerator
from iazar.generator.config_loader import config_loader
from iazar.generator.randomx_validator import RandomXValidator

LOGGER_NAME = "generator.random"
logger = logging.getLogger(LOGGER_NAME)
if not logger.hasHandlers():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

class RandomGenerator(BaseNonceGenerator):
    """Generador aleatorio uniforme para nonces.

    Estrategia:
    - Sobre‑genera k * batch_size candidatos (k dinámico) en 64 bits.
    - Sanitiza a 32 bits (Monero nonce) y elimina duplicados intra‑batch.
    - Calcula métricas (entropía, zero_density, uniqueness, pattern_score) vectorizadas.
    - Valida vía RandomX (pool interno) devolviendo sólo los nonces aceptados hasta batch_size.

    Config (desde global_config.json → sección random_generator, valores por defecto):
      random_generator: {
        "batch_candidate_factor": 4,
        "max_validation_workers": 8,
        "recent_nonces_size": 500,
        "max_attempt_loops": 8,
        "max_candidate_factor": 32,
        "min_entropy_threshold": 0.0,
        "pattern_score_min": 0.5
      }
    """

    DEFAULTS = {
        "batch_candidate_factor": 4,
        "max_validation_workers": 8,
        "recent_nonces_size": 500,
        "max_attempt_loops": 8,
        "max_candidate_factor": 32,
        "min_entropy_threshold": 0.0,
        "pattern_score_min": 0.5
    }

    FIELDNAMES = ["nonce", "entropy", "uniqueness", "zero_density", "pattern_score", "is_valid", "block_height"]

    def __init__(self, config: Optional[Dict] = None):
        merged = {**self.DEFAULTS, **(config or {}).get("random_generator", {})}
        super().__init__("random", merged)
        self._recent_lock = threading.RLock()
        self._validator = RandomXValidator((config or {}).get("randomx", {}))
        self._recent_nonces: List[int] = []  # ring buffer
        self._recent_size = int(self.config["recent_nonces_size"])
        self._last_block_height: Optional[int] = None
        self._validation_pool_workers = min(int(self.config["max_validation_workers"]), os.cpu_count() or 4)
        self._executor_lock = threading.Lock()
        self._executor = None  # Lazy ThreadPoolExecutor
        logger.info("[RandomGenerator] Initialized (workers=%d)" % self._validation_pool_workers)

    # -------------------- Public API --------------------
    def run_generation(self, block_height: int, block_data: dict, batch_size: int = 500) -> List[dict]:
        t0 = time.perf_counter()
        self._refresh_recent_cache(block_height)

        batch_factor = int(self.config["batch_candidate_factor"])
        max_factor = int(self.config["max_candidate_factor"])
        max_loops = int(self.config["max_attempt_loops"])

        accepted: List[dict] = []
        attempts = 0
        while len(accepted) < batch_size and attempts < max_loops:
            candidate_count = batch_size * batch_factor
            candidates = self._generate_candidates(candidate_count)
            # Métricas vectorizadas
            metrics = self._compute_metrics(candidates)
            # Filtro previo por métrica (reduce validaciones RandomX inútiles)
            mask_pre = (metrics['entropy'] >= self.config['min_entropy_threshold']) & \
                       (metrics['pattern_score'] >= self.config['pattern_score_min'])
            if not mask_pre.any():
                batch_factor = min(batch_factor * 2, max_factor)
                attempts += 1
                continue
            filtered = candidates[mask_pre]
            filtered_metrics = {k: v[mask_pre] for k, v in metrics.items()}
            # Validación RandomX
            results = self._validate_vector(filtered, block_data)
            for i, ok in enumerate(results):
                if not ok:
                    continue
                nonce = int(filtered[i])
                record = {
                    "nonce": nonce,
                    "entropy": round(float(filtered_metrics['entropy'][i]), 5),
                    "uniqueness": round(float(filtered_metrics['uniqueness'][i]), 5),
                    "zero_density": round(float(filtered_metrics['zero_density'][i]), 5),
                    "pattern_score": round(float(filtered_metrics['pattern_score'][i]), 5),
                    "is_valid": True,
                    "block_height": block_height
                }
                accepted.append(record)
                self._append_recent(nonce)
                if len(accepted) >= batch_size:
                    break
            attempts += 1
            if len(accepted) < batch_size:
                batch_factor = min(batch_factor * 2, max_factor)

        # Persistencia batch
        if accepted:
            self._append_csv(accepted)

        elapsed = time.perf_counter() - t0
        logger.info("[RandomGenerator] block=%s accepted=%d/%d attempts=%d elapsed=%.3fs", block_height, len(accepted), batch_size, attempts, elapsed)
        # METRIC: random_generator_batch_latency_seconds.observe(elapsed)
        return accepted

    # -------------------- Candidate Generation --------------------
    def _generate_candidates(self, count: int):
        if _HAS_NUMPY:
            # Sobre‑generar 20% para compensar duplicados al truncar a 32 bits
            raw64 = np.random.randint(0, 2**64, size=int(count * 1.2), dtype=np.uint64)
            # Sanitizar a 32 bits y deduplicar
            c32 = (raw64 & 0xFFFFFFFF).astype(np.uint32)
            if c32.size > count:
                # Deduplicación
                uniq = np.unique(c32)
                if uniq.size < count:
                    # Generar extras hasta completar
                    while uniq.size < count:
                        extra = (np.random.randint(0, 2**64, size=count - uniq.size, dtype=np.uint64) & 0xFFFFFFFF).astype(np.uint32)
                        uniq = np.unique(np.concatenate([uniq, extra]))
                c32 = uniq[:count]
            return c32
        else:  # pragma: no cover
            seen = set()
            out = []
            while len(out) < count:
                v = os.urandom(4)
                n = int.from_bytes(v, 'little')
                if n not in seen:
                    seen.add(n)
                    out.append(n)
            import numpy as np  # local import for uniform interface
            return np.array(out, dtype=np.uint32)

    # -------------------- Metrics --------------------
    def _compute_metrics(self, nonces):
        # nonces: np.ndarray uint32
        if not _HAS_NUMPY:
            # Fallback puro (menos eficiente)
            entropies = []
            zero_density = []
            pattern = []
            uniq_list = []
            recent_snapshot = self._recent_snapshot()
            for n in nonces.tolist():
                b = f"{n:032b}"  # 32 bits
                zeros = b.count('0')
                p0 = zeros / 32.0
                p1 = 1.0 - p0
                if 0 < p0 < 1:
                    ent = -(p0 * (p0 and (p0.bit_length() and 0)) + p1 * (p1 and (p1.bit_length() and 0)))  # Placeholder fallback
                else:
                    ent = 0.0
                entropies.append(ent)
                zero_density.append(p0)
                max_run0 = max((len(r) for r in b.split('1')), default=0)
                max_run1 = max((len(r) for r in b.split('0')), default=0)
                run_penalty = min(0.5, max(max_run0, max_run1) / 16)
                pattern.append(max(0.5, 1.0 - run_penalty))
                uniq_list.append(self._uniqueness_scalar(n, recent_snapshot))
            import numpy as _np
            return {
                'entropy': _np.array(entropies, dtype=_np.float32),
                'zero_density': _np.array(zero_density, dtype=_np.float32),
                'pattern_score': _np.array(pattern, dtype=_np.float32),
                'uniqueness': _np.array(uniq_list, dtype=_np.float32)
            }
        # Vectorizado
        bits = np.unpackbits(nonces.view(np.uint8)).reshape(-1, 32)
        zeros = (bits == 0).sum(axis=1)
        p0 = zeros / 32.0
        p1 = 1.0 - p0
        # Entropía binaria
        with np.errstate(divide='ignore', invalid='ignore'):
            entropy = -(p0 * np.log2(p0, where=(p0 > 0)) + p1 * np.log2(p1, where=(p1 > 0)))
            entropy = np.nan_to_num(entropy)
        # Max run (aprox) -> contamos runs de 1 y 0 mediante diferencias
        # Convert bits to transitions
        transitions = np.diff(bits, axis=1) != 0
        # Longest run estimation: (32 - number_of_transitions) / ??? (simplified heuristic)
        run_lengths = 32 - transitions.sum(axis=1)
        run_penalty = np.clip(run_lengths / 32.0, 0, 0.5)
        pattern_score = np.maximum(0.5, 1.0 - run_penalty)
        # Uniqueness: Hamming distance media con recientes
        recent = self._recent_snapshot()
        if recent.size == 0:
            uniqueness = np.full(nonces.shape[0], 1.0, dtype=np.float32)
        else:
            # Broadcast XOR
            xor = nonces[:, None] ^ recent[None, :]
            # Popcount vectorizado
            popcnt = np.unpackbits(xor.view(np.uint8), axis=2).sum(axis=2)
            uniqueness = np.clip(popcnt.mean(axis=1) / 32.0, 0.8, 0.99)
        return {
            'entropy': entropy.astype(np.float32),
            'zero_density': p0.astype(np.float32),
            'pattern_score': pattern_score.astype(np.float32),
            'uniqueness': uniqueness.astype(np.float32)
        }

    def _uniqueness_scalar(self, n: int, recent):  # pragma: no cover (fallback only)
        if recent.size == 0:
            return 1.0
        xor = recent ^ n
        popcnt = np.unpackbits(xor.view(np.uint8)).reshape(-1, 32).sum(axis=1)
        return max(0.8, min(0.99, float(popcnt.mean() / 32.0)))

    # -------------------- Validation --------------------
    def _validate_vector(self, nonces, block_data: dict):
        from concurrent.futures import ThreadPoolExecutor
        with self._executor_lock:
            if self._executor is None:
                from concurrent.futures import ThreadPoolExecutor as TPE
                self._executor = TPE(max_workers=self._validation_pool_workers, thread_name_prefix="rng-val")
        futures = []
        for n in nonces.tolist():
            futures.append(self._executor.submit(self._validator.validate, int(n), block_data))
        results = []
        for f in futures:
            try:
                results.append(bool(f.result()))
            except Exception as e:  # pragma: no cover
                logger.debug("Validation future error: %s", e)
                results.append(False)
        return results

    # -------------------- Recent Nonces Cache --------------------
    def _refresh_recent_cache(self, block_height: int):
        if self._last_block_height == block_height:
            return
        # Cargar training data (puede ser pesado ⇒ hacerlo una vez por bloque)
        self.training_data = self._load_training_data()
        recent: List[int] = []
        size = self._recent_size
        for row in reversed(self.training_data):
            if len(recent) >= size:
                break
            if str(row.get('is_valid', '')).lower() == 'true':
                try:
                    n = int(row['nonce']) & 0xFFFFFFFF
                    recent.append(n)
                except Exception:
                    continue
        with self._recent_lock:
            self._recent_nonces = recent[-size:]
            self._last_block_height = block_height

    def _append_recent(self, nonce: int):
        with self._recent_lock:
            self._recent_nonces.append(nonce)
            if len(self._recent_nonces) > self._recent_size:
                self._recent_nonces.pop(0)

    def _recent_snapshot(self):
        if not _HAS_NUMPY:
            import numpy as _np
            return _np.array(self._recent_nonces, dtype=_np.uint32)
        with self._recent_lock:
            return np.array(self._recent_nonces, dtype=np.uint32) if self._recent_nonces else np.empty(0, dtype=np.uint32)

    # -------------------- CSV Persistence --------------------
    def _append_csv(self, rows: List[dict]):
        base_dir = Path(os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        path = base_dir / "data" / "nonces_exitosos.csv"
        tmp_path = path.with_suffix(".tmp")
        path.parent.mkdir(parents=True, exist_ok=True)
        write_header = not path.exists()
        try:
            with open(tmp_path, 'a', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
                if write_header:
                    writer.writeheader()
                                for r in rows:
                    # Sanitización CSV: (aunque todos son numéricos / bool) aseguramos tipos
                    safe = {
                        "nonce": int(r["nonce"]) & 0xFFFFFFFF,
                        "entropy": float(r["entropy"]),
                        "uniqueness": float(r["uniqueness"]),
                        "zero_density": float(r["zero_density"]),
                        "pattern_score": float(r["pattern_score"]),
                        "is_valid": bool(r["is_valid"]),
                        "block_height": int(r["block_height"])
                    }
                    writer.writerow(safe)
            # Rename atómico al final (append seguro: concatenamos tmp→final)
            with open(tmp_path, 'r', encoding='utf-8') as src, \
                 open(path, 'a', encoding='utf-8') as dst:
                if write_header:
                    # Ya se escribió header en tmp y no existía file → mover directamente
                    pass
                dst.write(src.read())
            tmp_path.unlink(missing_ok=True)
        except Exception as e:
            logger.exception("Error writing CSV batch (%s): %s", path, e)
            try:
                tmp_path.unlink(missing_ok=True)
            except Exception:
                pass

    def _load_training_data(self):
        """Carga 'nonce_training_data.csv' en memoria ligera (sólo últimas N líneas).

        Optimización:
          - Evitar cargar TODO el archivo si es muy grande; limitar a última ventana.
          - Si el archivo crece, se puede implementar un tail incremental.
        """
        base_dir = Path(os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        path = base_dir / "data" / "nonce_training_data.csv"
        window = max(self._recent_size * 4, 2000)
        if not path.exists():
            return []
        rows = []
        try:
            # Lectura eficiente tipo tail manual
            # (simple approach: leer completo; optimizar con mmap si excede tamaño).
            with open(path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    rows.append(row)
            if len(rows) > window:
                rows = rows[-window:]
        except Exception as e:
            logger.warning("Failed to load training data (%s): %s", path, e)
            return []
        return rows

    # -------------------- Shutdown / Cleanup --------------------
    def close(self):
        """Cierre ordenado del pool de validación (se puede llamar desde el orquestador)."""
        from concurrent.futures import ThreadPoolExecutor
        with self._executor_lock:
            if self._executor:
                self._executor.shutdown(wait=False, cancel_futures=True)
                self._executor = None
        # No destruimos validator (podría ser compartido).

    # -------------------- Optional Rotation (Stub) --------------------
    def rotate_daily(self):
        """(Opcional) Rotar archivo CSV diario. Llamar cada cambio de fecha desde el orquestador."""
        base_dir = Path(os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        data_dir = base_dir / "data"
        main_path = data_dir / "nonces_exitosos.csv"
        if not main_path.exists():
            return
        today_tag = time.strftime("%Y%m%d")
        rotated = data_dir / f"nonces_exitosos_{today_tag}.csv"
        if rotated.exists():
            return
        try:
            # Simplemente copiar estado actual como snapshot inicial
            import shutil
            shutil.copy2(main_path, rotated)
            logger.info("Rotated snapshot created: %s", rotated.name)
        except Exception as e:
            logger.debug("Rotation snapshot failed: %s", e)

# -------------------- Registro en Factory --------------------

def create_generator(config: Optional[Dict] = None) -> RandomGenerator:
    """
    Factory para integración dinámica en el orquestador.
    """
    return RandomGenerator(config=config)
