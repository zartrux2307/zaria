from __future__ import
 annotations
import os
import math
import time
import json
import threading
import logging
from pathlib import Path
from typing import Optional, Sequence, Dict, Any, List
import random

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None  # type: ignore

logger = logging.getLogger("generator.entropy")

CSV_FIELDS = ["nonce", "entropy", "uniqueness", "zero_density", "pattern_score", "is_valid", "block_height"]
UINT32_MASK = 0xFFFFFFFF
DEFAULT_TARGET_ENTROPY = (5.5, 7.8)  # rango aceptable inicial (bits de Shannon sobre 32 bits)
SMOOTHING_ALPHA = 0.05  # EMA para histogramas
RECALC_INTERVAL = 30.0  # segundos entre recalculo de distribución objetivo
BATCH_SIZE = 500
MAX_INTERNAL_FACTOR = 4  # Generamos hasta 4× y filtramos
TRAIN_SAMPLE_LIMIT = 200_000  # Máximo de filas a considerar del histórico (sliding window)

class EntropyModel:
    """Mantiene histograma de entropía y zero_density objetivo y permite muestreo.

    Usa bins dinámicos (por defecto 24 para entropía, 20 para zero density) y
    actualiza mediante EMA para adaptación suave.
    """

    def __init__(self, entropy_bins: int = 24, zd_bins: int = 20):
        self.entropy_bins = entropy_bins
        self.zd_bins = zd_bins
        self._lock = threading.Lock()
        self._last_recalc = 0.0
        # histogramas normalizados
        self.entropy_hist = np.ones(entropy_bins, dtype=np.float64) if np else None
        self.zd_hist = np.ones(zd_bins, dtype=np.float64) if np else None
        self.entropy_range = (0.0, 8.0)
        self.zd_range = (0.0, 1.0)

    def maybe_recalc(self, samples: np.ndarray, zd_samples: np.ndarray, now: float):
        if not np:
            return
        if now - self._last_recalc < RECALC_INTERVAL:
            return
        with self._lock:
            h_ent, _ = np.histogram(samples, bins=self.entropy_bins, range=self.entropy_range)
            h_zd, _ = np.histogram(zd_samples, bins=self.zd_bins, range=self.zd_range)
            # Suavizado EMA
            self.entropy_hist = (1 - SMOOTHING_ALPHA) * self.entropy_hist + SMOOTHING_ALPHA * (h_ent + 1)
            self.zd_hist = (1 - SMOOTHING_ALPHA) * self.zd_hist + SMOOTHING_ALPHA * (h_zd + 1)
            # Normalizar
            self.entropy_hist /= self.entropy_hist.sum()
            self.zd_hist /= self.zd_hist.sum()
            self._last_recalc = now
            logger.debug("EntropyModel recalculated histograms")

    def sample_target_windows(self, k: int) -> List[tuple[float, float, float, float]]:
        """Devuelve k ventanas (entropy_min, entropy_max, zd_min, zd_max)."""
        if not np or self.entropy_hist is None or self.zd_hist is None:
            # Fallback estático
            return [(DEFAULT_TARGET_ENTROPY[0], DEFAULT_TARGET_ENTROPY[1], 0.2, 0.8)] * k
        with self._lock:
            ent_idxs = np.random.choice(self.entropy_hist.size, size=k, p=self.entropy_hist)
            zd_idxs = np.random.choice(self.zd_hist.size, size=k, p=self.zd_hist)
        ent_bin_w = (self.entropy_range[1] - self.entropy_range[0]) / self.entropy_hist.size
        zd_bin_w = (self.zd_range[1] - self.zd_range[0]) / self.zd_hist.size
        windows = []
        for ei, zi in zip(ent_idxs, zd_idxs):
            e_min = self.entropy_range[0] + ei * ent_bin_w
            e_max = e_min + ent_bin_w
            z_min = self.zd_range[0] + zi * zd_bin_w
            z_max = z_min + zd_bin_w
            windows.append((e_min, e_max, z_min, z_max))
        return windows

class EntropyBasedGenerator:
    """Generador orientado por perfil de entropía / densidad de ceros.

    Interfaz esperada por el orquestador:
    - run_generation(block_height: int, block_data: dict, batch_size: int) -> List[Dict]
    """

    NAME = "entropy"

    def __init__(self, config: Optional[Dict[str, Any]] = None, base_dir: Optional[Path] = None):
        self.config = config or {}
        self.base_dir = Path(base_dir or os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        self.data_dir = self.base_dir / "data"
        self.training_csv = self.data_dir / "nonce_training_data.csv"
        self._rng = random.SystemRandom()
        self.model = EntropyModel()
        self._last_training_load = 0.0
        self.training_entropy = None  # type: ignore
        self.training_zd = None  # type: ignore
        self.randomx_validator = None  # inyectado externamente opcional
        self._load_initial_training()
        logger.info("[entropy_based] Initialized.")

    # ------------------------------------------------------------------
    # Carga de histórico
    def _load_initial_training(self):
        if not np:
            logger.warning("NumPy no disponible; se usará modo simplificado")
            return
        if not self.training_csv.exists():
            logger.warning("[EntropyBasedGenerator] No training data found at %s", self.training_csv)
            return
        try:
            import pandas as pd  # Lazy import
            df = pd.read_csv(self.training_csv, usecols=["entropy", "zero_density"], nrows=TRAIN_SAMPLE_LIMIT)
            self.training_entropy = df["entropy"].to_numpy(dtype=np.float64, copy=True)
            self.training_zd = df["zero_density"].to_numpy(dtype=np.float64, copy=True)
            now = time.time()
            self.model.maybe_recalc(self.training_entropy, self.training_zd, now)
            self._last_training_load = now
            logger.info("Entropy training data loaded: %d samples", len(df))
        except Exception:
            logger.exception("Error loading training data")

    def maybe_reload_training(self):
        if not np:
            return
        interval = self.config.get("entropy_training_reload_interval", 300)
        now = time.time()
        if now - self._last_training_load < interval:
            return
        self._load_initial_training()

    # ------------------------------------------------------------------
    # Métricas
    def _entropy32(self, values: Any) -> Any:
        if not np:
            # Fallback rápido: contar bits set y aproximar entropía
            out = []
            for v in values:
                x = v & UINT32_MASK
                ones = bin(x).count("1")
                p = ones / 32.0
                if p in (0, 1):
                    out.append(0.0)
                else:
                    out.append(- (p * math.log2(p) + (1 - p) * math.log2(1 - p)))
            return out
        arr = np.asarray(values, dtype=np.uint32)
        # Probabilidad de bit 1 global (approx por vector) -> entropía binomial
        ones = np.unpackbits(arr.view(np.uint8)).reshape(-1, 32).sum(axis=1)
        p = ones / 32.0
        # Evitar log2(0)
        p = np.clip(p, 1e-9, 1 - 1e-9)
        return - (p * np.log2(p) + (1 - p) * np.log2(1 - p))

    def _zero_density(self, values: Any) -> Any:
        if not np:
            out = []
            for v in values:
                x = v & UINT32_MASK
                zeros = 32 - bin(x).count("1")
                out.append(zeros / 32.0)
            return out
        arr = np.asarray(values, dtype=np.uint32)
        ones = np.unpackbits(arr.view(np.uint8)).reshape(-1, 32).sum(axis=1)
        return (32 - ones) / 32.0

    def _pattern_score(self, values: Any) -> Any:
        # Heurística placeholder: penaliza secuencias repetitivas de 4 bits
        if not np:
            scores = []
            for v in values:
                x = v & UINT32_MASK
                bits = f"{x:032b}"
                repeats = sum(bits[i:i+4] == bits[i+4:i+8] for i in range(0, 24, 4))
                scores.append(max(0.0, 1.0 - repeats / 8.0))
            return scores
        arr = np.asarray(values, dtype=np.uint32)
        # Vectorizado básico
        bytes_view = arr.view(np.uint8).reshape(-1, 4)
        # Simple proxy: desviación estándar de bytes normalizada
        std = bytes_view.std(axis=1)
        max_std = 74.0  # aprox máximo para bytes distribuidos
        return np.clip(std / max_std, 0, 1)

    # ------------------------------------------------------------------
    def _generate_raw(self, n: int) -> List[int]:
        # SystemRandom para mitigación de sesgos; si se desea rendimiento extremo, se puede pasar a os.urandom + struct.
        return [self._rng.getrandbits(32) for _ in range(n)]

    def _filter_by_windows(self, nonces: List[int], windows: Sequence[tuple[float, float, float, float]]):
        if not nonces:
            return []
        if not np:
            # Fallback: no filtrado por ventanas
            return nonces
        arr = np.asarray(nonces, dtype=np.uint32)
        ent = self._entropy32(arr)
        zd = self._zero_density(arr)
        mask_total = np.zeros(arr.size, dtype=bool)
        for e_min, e_max, z_min, z_max in windows:
            mask = (ent >= e_min) & (ent < e_max) & (zd >= z_min) & (zd < z_max)
            mask_total |= mask
        return arr[mask_total].tolist()

    # ------------------------------------------------------------------
    def run_generation(self, block_height: int, block_data: Dict[str, Any], batch_size: int = BATCH_SIZE) -> List[Dict[str, Any]]:
        start = time.perf_counter()
        self.maybe_reload_training()
        # 1. Generar sobrecapacidad
        internal_target = min(batch_size * MAX_INTERNAL_FACTOR, batch_size * 6)
        raw_nonces = self._generate_raw(internal_target)
        # 2. Seleccionar ventanas objetivo
        windows = self.model.sample_target_windows(k=max(1, internal_target // batch_size))
        # 3. Filtrar
        selected = self._filter_by_windows(raw_nonces, windows)
        if len(selected) < batch_size:
            # Rellenar si insuficiente
            selected.extend(self._generate_raw(batch_size - len(selected)))
        selected = selected[:batch_size]
        # 4. Calcular métricas
        entropy_vals = self._entropy32(selected)
        zd_vals = self._zero_density(selected)
        pattern_vals = self._pattern_score(selected)
        # Uniqueness simple: usar hash mod N (placeholder); el orquestador puede recalcular global
        if np:
            arr = np.asarray(selected, dtype=np.uint32)
            # Hash mixing
            mix = (arr ^ (arr << 13) ^ (arr >> 7) ^ (arr << 3)) & UINT32_MASK
            # Escalar a [0,1]
            uniqueness = (mix.astype(np.float64) / UINT32_MASK)
        else:
            uniqueness = [((v ^ (v << 13) ^ (v >> 7) ^ (v << 3)) & UINT32_MASK) / UINT32_MASK for v in selected]

        records = []
        for i, nonce in enumerate(selected):
            rec = {
                "nonce": int(nonce) & UINT32_MASK,
                "entropy": float(entropy_vals[i]) if np else float(entropy_vals[i]),
                "uniqueness": float(uniqueness[i]),
                "zero_density": float(zd_vals[i]) if np else float(zd_vals[i]),
                "pattern_score": float(pattern_vals[i]) if np else float(pattern_vals[i]),
                "is_valid": True,  # Validación RandomX se aplica aguas abajo
                "block_height": int(block_height),
            }
            records.append(rec)
        latency = time.perf_counter() - start
        logger.debug("entropy generation batch=%d latency=%.4fs", len(records), latency)
        return records

# Factory para registro automático
GENERATORS = {EntropyBasedGenerator.NAME: EntropyBasedGenerator}
