"""
nonce_orchestrator.py
---------------------
Orquestador principal para la generación, validación y envío de nonces en pipeline
RandomX (Monero) nivel producción.

Características clave:
- Integración con job real vía Shared Memory (pool_job_provider).
- Soporte para múltiples generadores concurrentes (range, adaptive, ml, entropy, sequence, hybrid, random, grouped).
- Validación RandomX real (si los generadores no la han hecho internamente / no aportan hash).
- Persistencia centralizada CSV (NonceCSVWriter) formato estándar:
    nonce,entropy,uniqueness,zero_density,pattern_score,is_valid,block_height
- Pacing target_rate (ej: 500/s) usando token bucket + ajuste dinámico.
- Deduplicación configurable y backpressure (drop_oldest / drop_newest / block).
- Envío de shares válidos al proxy via Shared Memory (shm_solution_writer).
- Recarga caliente de configuración (pesos generadores, parámetros orchestrator).
- Evaluadores opcionales asincrónicos (si están presentes).
- Logs estructurados y puntos METRIC listos para instrumentación.

Requisitos:
- pool_job_provider.py (SharedMemoryJobProvider)
- shm_solution_writer.py (SharedMemorySolutionWriter)
- randomx_validator.py (RandomXValidator real)
"""

from __future__ import annotations
import os
import sys
import time
import json
import math
import signal
import logging
import threading
import queue
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Callable, Any, Tuple
from collections import deque
from concurrent.futures import ThreadPoolExecutor, Future

# ---------------- Logging base ----------------
logger = logging.getLogger("orchestrator")
if not logger.hasHandlers():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

# ---------------- Config Cache ----------------
class _ConfigCache:
    _lock = threading.Lock()
    _cache: Dict[str, Dict] = {}
    _mtimes: Dict[str, float] = {}

    @classmethod
    def load(cls, path: Path) -> Dict:
        try:
            m = path.stat().st_mtime
        except FileNotFoundError:
            return {}
        p = path.as_posix()
        with cls._lock:
            if p in cls._cache and cls._mtimes.get(p) == m:
                return cls._cache[p]
            try:
                with path.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                cls._cache[p] = data
                cls._mtimes[p] = m
                return data
            except Exception:
                logger.warning("Failed loading config %s", path, exc_info=True)
                return cls._cache.get(p, {})

# ---------------- Dependencias ----------------
from iazar.generator.randomx_validator import RandomXValidator
from iazar.generator.NonceCSVWriter import NonceCSVWriter

# Generadores
from iazar.generator.range_based_generator import RangeBasedGenerator
from iazar.generator.entropy_based_generator import EntropyBasedGenerator
from iazar.generator.sequence_based_generator import SequenceBasedGenerator
from iazar.generator.adaptive_generator import AdaptiveGenerator
from iazar.generator.random_generator import RandomGenerator
from iazar.generator.ml_based_generator import MLBasedGenerator
from iazar.generator.hybrid_generator import HybridGenerator
from iazar.generator.nonce_generator import GroupedTopNonceGenerator as GroupedGenerator

# Job + Share SHM
from iazar.proxy.pool_job_provider import SharedMemoryJobProvider
from iazar.generator.shm_solution_writer import SharedMemorySolutionWriter

# Evaluadores opcionales
try:
    from iazar.evaluation.correlation_analysis import CorrelationAnalyzer
    from iazar.evaluation.distribution_analyzer import DistributionAnalyzer
    from iazar.evaluation.entropy_analysis import EntropyAnalyzer
    from iazar.evaluation.nonce_quality_filter import NonceQualityFilter
    from iazar.evaluation.survival_analyzer import SurvivalAnalyzer
    from iazar.evaluation.calculatenonce import NonceCalculator
except Exception:
    CorrelationAnalyzer = DistributionAnalyzer = EntropyAnalyzer = NonceQualityFilter = SurvivalAnalyzer = NonceCalculator = None
    logger.info("Evaluators not fully available; proceeding without them.")

# ---------------- Utilidades ----------------
def difficulty_to_target(difficulty: int) -> int:
    if not isinstance(difficulty, int) or difficulty <= 0:
        return (1 << 256) - 1
    return ((1 << 256) - 1) // difficulty

# ---------------- Rate Control ----------------
class TokenBucket:
    def __init__(self, rate_per_sec: int, burst: Optional[int] = None):
        self.capacity = burst or rate_per_sec
        self.rate = rate_per_sec
        self.tokens = float(self.capacity)
        self.timestamp = time.perf_counter()
        self._lock = threading.Lock()

    def consume(self, n: int) -> bool:
        with self._lock:
            now = time.perf_counter()
            delta = now - self.timestamp
            self.timestamp = now
            self.tokens = min(self.capacity, self.tokens + delta * self.rate)
            if self.tokens >= n:
                self.tokens -= n
                return True
            return False

    def refill_now(self):
        with self._lock:
            self.tokens = float(self.capacity)
            self.timestamp = time.perf_counter()

# ---------------- Registry Generadores ----------------
class GeneratorRegistry:
    def __init__(self):
        self._classes: Dict[str, Callable[..., Any]] = {}
    def register(self, key: str, cls):
        self._classes[key] = cls
    def create(self, key: str, config: Dict, validator: RandomXValidator):
        cls = self._classes.get(key)
        if not cls:
            raise KeyError(f"Generator '{key}' not registered.")
        try:
            # Muchos generadores aceptan (config, validator); otros sólo config
            return cls(config=config, validator=validator)
        except TypeError:
            return cls(config=config)

# ---------------- Orquestador ----------------
class NonceOrchestrator:
    def __init__(self, config: Optional[Dict] = None):
        base_dir = Path(os.environ.get("IAZAR_BASE", "C:/zarturxia/src/iazar"))
        self.base_dir = base_dir
        self.config_path = base_dir / "config" / "global_config.json"
        self.global_config = _ConfigCache.load(self.config_path)

        orch_cfg = (config or {}).get("orchestrator", {}) or self.global_config.get("orchestrator", {})
        self.target_rate = int(orch_cfg.get("target_rate", 500))
        self.loop_interval = float(orch_cfg.get("loop_interval_sec", 1.0))
        self.max_queue = int(orch_cfg.get("max_queue", 10000))
        self.merge_max_per_generator = int(orch_cfg.get("merge_max_per_generator", 500))
        self.dedup_window = int(orch_cfg.get("deduplicate_recent_window", 20000))
        self.backpressure_policy = orch_cfg.get("backpressure_policy", "drop_oldest")
        self.enable_evaluators = bool(orch_cfg.get("enable_evaluators", True))
        self.generator_pool_size = int(orch_cfg.get("generator_pool", 6))
        self.share_submit_retry = int(orch_cfg.get("share_submit_retry", 3))
        self.job_prefix = orch_cfg.get("job_shm_prefix", "5555")

        # Validator
        self.validator = RandomXValidator(self.global_config.get("randomx", {}))

        # Job provider & share writer
        self.job_provider = SharedMemoryJobProvider(prefix=self.job_prefix)
        self.solution_writer = SharedMemorySolutionWriter(prefix=self.job_prefix)

        # Registry + Generators
        self.registry = GeneratorRegistry()
        self._register_generators()
        weight_cfg = (config or {}).get("generator_weights", {}) or self.global_config.get("generator_weights", {})
        self.generator_weights = weight_cfg
        self.generators = self._instantiate_generators(config or {})

        # Writer CSV central
        self.writer = NonceCSVWriter(self.base_dir / "data" / "nonces_exitosos.csv",
                                     batch_size=500,
                                     rotate_daily=True)

        # Cola interna y pacing
        self.output_queue: "queue.Queue[dict]" = queue.Queue(maxsize=self.max_queue)
        self.rate_bucket = TokenBucket(rate_per_sec=self.target_rate, burst=self.target_rate)

        # Deduplicación
        self._recent_set: deque[int] = deque(maxlen=self.dedup_window)
        self._recent_lookup: set[int] = set()
        self._recent_lock = threading.Lock()

        # Evaluadores
        self.evaluators = self._init_evaluators()

        # Pools
        self.pool = ThreadPoolExecutor(max_workers=self.generator_pool_size, thread_name_prefix="gen")
        self.analysis_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="eval")

        # Control
        self.running = threading.Event()
        self.running.set()
        self._last_config_check = time.time()
        self._config_reload_interval = 5.0
        self._last_stats_log = time.time()
        self._stats_interval = 15.0
        self._accepted_shares = 0
        self._last_rate_timestamp = time.time()
        self._dispatched_in_window = 0

        self._setup_signals()

        logger.info("NonceOrchestrator initialized target_rate=%d/s generators=%s",
                    self.target_rate, list(self.generators.keys()))

    # ----- Registro de Generadores -----
    def _register_generators(self):
        self.registry.register("range", RangeBasedGenerator)
        self.registry.register("entropy", EntropyBasedGenerator)
        self.registry.register("sequence", SequenceBasedGenerator)
        self.registry.register("adaptive", AdaptiveGenerator)
        self.registry.register("random", RandomGenerator)
        self.registry.register("ml", MLBasedGenerator)
        self.registry.register("hybrid", HybridGenerator)
        self.registry.register("grouped", GroupedGenerator)

    def _instantiate_generators(self, config: Dict):
        gens = {}
        for key in self.registry._classes.keys():
            try:
                if self.generator_weights.get(key, 0) <= 0:
                    continue
                inst = self.registry.create(key, config, self.validator)
                gens[key] = inst
                logger.info("Generator '%s' active (%s)", key, type(inst).__name__)
            except Exception:
                logger.exception("Failed to init generator '%s'", key)
        if not gens:
            logger.warning("No generators instantiated (weights all zero?)")
        return gens

    # ----- Evaluadores -----
    def _init_evaluators(self):
        if not self.enable_evaluators:
            return {}
        ev = {}
        try:
            if NonceQualityFilter:
                ev["quality"] = NonceQualityFilter(self.global_config.get("quality_filter", {}))
            if CorrelationAnalyzer:
                ev["correlation"] = CorrelationAnalyzer()
            if DistributionAnalyzer:
                ev["distribution"] = DistributionAnalyzer()
            if EntropyAnalyzer:
                ev["entropy"] = EntropyAnalyzer()
            if SurvivalAnalyzer:
                ev["survival"] = SurvivalAnalyzer()
            if NonceCalculator:
                ev["calculator"] = NonceCalculator()
        except Exception:
            logger.exception("Evaluator initialization error")
        return ev

    # ----- Main Loop -----
    def start(self):
        logger.info(">>> Orchestrator main loop START")
        iteration = 0
        try:
            while self.running.is_set():
                iteration += 1
                loop_start = time.perf_counter()

                block_meta = self._current_job_blockdata()

                futures: List[Future] = []
                if not self.generators:
                    logger.warning("No active generators. Sleeping.")
                    time.sleep(1.5)
                    self._maybe_reload_config()
                    continue

                for key, gen in self.generators.items():
                    futures.append(self.pool.submit(self._run_generator_safe,
                                                    key, gen,
                                                    block_meta["height"], block_meta))

                all_records: List[dict] = []
                for fut in futures:
                    try:
                        res = fut.result()
                        if res:
                            if len(res) > self.merge_max_per_generator:
                                res = res[:self.merge_max_per_generator]
                            all_records.extend(res)
                    except Exception:
                        logger.exception("Generator future failed")

                if all_records:
                    filtered = self._post_process_and_enqueue(all_records)
                    if self.enable_evaluators and filtered:
                        self._schedule_evaluators(filtered, block_meta)

                self._drain_to_proxy(block_meta)

                self._maybe_reload_config()
                self._maybe_log_stats()

                elapsed = time.perf_counter() - loop_start
                remain = self.loop_interval - elapsed
                if remain > 0:
                    time.sleep(remain)
        finally:
            logger.info(">>> Orchestrator loop EXIT")
            self.shutdown()

    # ----- Obtención job → block_data -----
    def _current_job_blockdata(self) -> Dict[str, Any]:
        job = self.job_provider.current_job()
        if not job:
            # fallback temporal (NO producción prolongada)
            seed = "0" * 64
            blob = b"\x00" * 84
            target = (1 << 256) - 1
            return {"height": 0, "seed": seed, "blob": blob, "target": target, "nonce_offset": 39, "job_id": "none"}
        # job estructura esperada:
        # blob_hex, seed_hash, job_id, height, target_qword (64 bits parcial), algo
        blob_hex = job["blob_hex"]
        blob = bytes.fromhex(blob_hex)
        # target del pool parcial (64 bits). Derivar target largo usando difficulty si existiera.
        # Aquí asumimos target_qword ya es umbral base; extendemos a 256 bits simple.
        qword = int(job["target_qword"])
        # Construir target 256 bit aproximado escalando (shift)
        target_256 = (qword << (256 - 64)) | ((1 << (256 - 64)) - 1)
        return {
            "height": job["height"],
            "seed": job["seed_hash"],
            "blob": blob,
            "target": target_256,
            "nonce_offset": 39,   # ajustar si difiere
            "job_id": job["job_id"]
        }

    # ----- Ejecutar Generador -----
    def _run_generator_safe(self, key: str, gen, height: int, block_data: dict):
        try:
            return gen.run_generation(height, block_data, batch_size=500)
        except Exception as e:
            logger.error("Generator %s error: %s", key, e)
            return []

    # ----- Post-proceso + cola -----
    def _post_process_and_enqueue(self, records: List[dict]) -> List[dict]:
        cleaned: List[dict] = []
        to_write: List[dict] = []
        with self._recent_lock:
            for r in records:
                try:
                    n = int(r["nonce"]) & 0xFFFFFFFF
                except Exception:
                    continue
                if n in self._recent_lookup:
                    continue
                self._recent_set.append(n)
                self._recent_lookup.add(n)
                cleaned.append(r)
            # limpiar lookup si excede ventana (deque ya recorta)
            if len(self._recent_lookup) > self.dedup_window:
                # reconstruir set con contenidos actuales del deque
                self._recent_lookup = set(self._recent_set)

        for r in cleaned:
            # Validación secundaria (si generador no aportó hash y se desea reconfirmar) podría hacerse aquí
            to_write.append({
                "nonce": r["nonce"],
                "entropy": r.get("entropy", 0.0),
                "uniqueness": r.get("uniqueness", 1.0),
                "zero_density": r.get("zero_density", 0.0),
                "pattern_score": r.get("pattern_score", 0.0),
                "is_valid": r.get("is_valid", False),
                "block_height": r.get("block_height", 0)
            })
            self._enqueue_record(r)
        if to_write:
            self.writer.write_many(to_write)
        return cleaned

    def _enqueue_record(self, r: dict):
        if not self._offer_queue(r):
            # backpressure
            if self.backpressure_policy == "drop_newest":
                return
            elif self.backpressure_policy == "drop_oldest":
                try:
                    self.output_queue.get_nowait()
                except queue.Empty:
                    return
                self._offer_queue(r)
            elif self.backpressure_policy == "block":
                self.output_queue.put(r)
            else:
                return

    def _offer_queue(self, item: dict) -> bool:
        try:
            self.output_queue.put_nowait(item)
            return True
        except queue.Full:
            return False

    # ----- Drain hacia Proxy / Submit Shares -----
    def _drain_to_proxy(self, block_meta: dict):
        """
        Extrae elementos de la cola respetando el rate y envía shares válidos
        (is_valid=True) al proxy vía SHM (solution writer).
        Si el generador ya tenía hash (r.get('hash')), se podría usar para
        validación adicional (TODO: si agregas hash).
        """
        dispatched = 0
        job_id = block_meta.get("job_id", "")
        while not self.output_queue.empty() and self.rate_bucket.consume(1):
            try:
                item = self.output_queue.get_nowait()
            except queue.Empty:
                break
            dispatched += 1
            self._dispatched_in_window += 1
            if item.get("is_valid"):
                # Recalcular hash opcional si quieres confirmar (coste adicional)
                # Aquí asumimos generadores con validator real => confíamos en is_valid.
                # Para robustez total: ok, h = self.validator.validate(item['nonce'], block_meta, return_hash=True)
                # if not ok: continue
                # else usar h
                fake_hash = os.urandom(32)  # Placeholder si aún generadores no suministran hash real
                # TODO: Reemplazar fake_hash por hash real cuando generadores devuelvan "hash".
                submitted = False
                for _ in range(self.share_submit_retry):
                    if self.solution_writer.try_submit(job_id, item["nonce"], fake_hash, True):
                        submitted = True
                        self._accepted_shares += 1
                        break
                    time.sleep(0.001)
                if not submitted:
                    logger.debug("Share submit buffer busy; dropped share nonce=%s", item["nonce"])
        if dispatched:
            logger.debug("Dispatched %d queued nonces (valid_shares=%d)", dispatched, self._accepted_shares)

        # Ajuste dinámico simple de pacing
        now = time.time()
        if now - self._last_rate_timestamp >= 1.0:
            actual_rate = self._dispatched_in_window / (now - self._last_rate_timestamp)
            # METRIC: orchestrator_dispatch_rate.set(actual_rate)
            if actual_rate < self.target_rate * 0.85:
                self.rate_bucket.refill_now()
            self._dispatched_in_window = 0
            self._last_rate_timestamp = now

    # ----- Evaluadores -----
    def _schedule_evaluators(self, records: List[dict], block_meta: dict):
        for name, ev in self.evaluators.items():
            self.analysis_pool.submit(self._run_evaluator, name, ev, records, block_meta)

    def _run_evaluator(self, name: str, evaluator, records: List[dict], block_meta: dict):
        try:
            evaluator.evaluate(records, block_meta)
        except Exception:
            logger.debug("Evaluator %s failed", name, exc_info=True)

    # ----- Hot Reload -----
    def _maybe_reload_config(self):
        now = time.time()
        if now - self._last_config_check < self._config_reload_interval:
            return
        self._last_config_check = now
        new_cfg = _ConfigCache.load(self.config_path)
        if not new_cfg:
            return
        new_weights = new_cfg.get("generator_weights", {})
        if new_weights and new_weights != self.generator_weights:
            logger.info("Reloading generator weights: %s", new_weights)
            self.generator_weights = new_weights
            # Activar nuevos
            for k, w in new_weights.items():
                if w > 0 and k not in self.generators:
                    try:
                        inst = self.registry.create(k, {}, self.validator)
                        self.generators[k] = inst
                        logger.info("Activated generator '%s' after reload", k)
                    except Exception:
                        logger.exception("Could not activate generator %s", k)
            # Desactivar pesados 0
            to_remove = [k for k, w in new_weights.items() if w == 0 and k in self.generators]
            for k in to_remove:
                try:
                    self.generators[k].close()
                except Exception:
                    pass
                del self.generators[k]
                logger.info("Deactivated generator '%s'", k)

    # ----- Stats -----
    def _maybe_log_stats(self):
        now = time.time()
        if now - self._last_stats_log >= self._stats_interval:
            in_queue = self.output_queue.qsize()
            logger.info("[STATS] queue=%d accepted_shares=%d active_generators=%d",
                        in_queue, self._accepted_shares, len(self.generators))
            self._last_stats_log = now

    # ----- Signals & Shutdown -----
    def _setup_signals(self):
        if os.name == "nt":
            return
        try:
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
        except Exception:
            logger.warning("Signal handlers not set.", exc_info=True)

    def _signal_handler(self, signum, frame):
        logger.info("Signal %s received -> shutdown", signum)
        self.running.clear()

    def shutdown(self):
        if self.running.is_set():
            self.running.clear()
        logger.info("Shutting down orchestrator...")
        try:
            self.pool.shutdown(wait=False, cancel_futures=True)
            self.analysis_pool.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        try:
            NonceCSVWriter.close_all()
        except Exception:
            pass
        for g in self.generators.values():
            try:
                g.close()
            except Exception:
                pass
        try:
            self.validator.close()
        except Exception:
            pass
        logger.info("Orchestrator stopped.")

# ---------------- CLI ----------------
def _parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--debug", action="store_true", help="Enable DEBUG logging")
    return ap.parse_args()

def main():
    args = _parse_args()
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        for lg in ["orchestrator", "generator.range", "generator.adaptive",
                   "generator.random", "generator.ml", "generator.grouped"]:
            logging.getLogger(lg).setLevel(logging.DEBUG)
    orch = NonceOrchestrator()
    try:
        orch.start()
    except KeyboardInterrupt:
        pass
    finally:
        orch.shutdown()

if __name__ == "__main__":
    main()
