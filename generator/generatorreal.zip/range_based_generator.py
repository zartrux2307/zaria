from __future__ import annotations
import os
import csv
import time
import random
import logging
import threading
from pathlib import Path
from typing import Dict, List, Set, Optional, Iterable, Tuple
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

from iazar.generator.nonce_generator import BaseNonceGenerator  # Interface base
from iazar.generator.randomx_validator import RandomXValidator   # Validador RandomX

__all__ = ["RangeBasedGenerator"]

# Campos estándar compartidos en toda la arquitectura
CSV_FIELDS = [
    "nonce", "entropy", "uniqueness", "zero_density", "pattern_score", "is_valid", "block_height"
]

class RangeBasedGenerator(BaseNonceGenerator):
    """Generador de nonces basado en rangos históricos optimizados.

    Estrategia:
    - Mantiene una lista de rangos (inclusive) con mayor tasa histórica de aceptación.
    - Para cada batch sobre-muestrea (factor dinámico) para compensar filtrado/validación.
    - Ajusta un *score* por rango (éxitos recientes / intentos) y aplica *roulette selection* ponderada.
    """

    MAX_NONCE = 0xFFFFFFFF
    RECENT_NONCES_TARGET = 500
    DEFAULT_RANGES: List[Tuple[int, int]] = [
        (1_000_000, 2_000_000),
        (5_000_000, 6_000_000),
        (8_000_000, 9_000_000),
    ]
    MAX_VALIDATION_WORKERS = max(2, min(16, os.cpu_count() or 4))
    MIN_OVER_SAMPLING = 2.0
    MAX_OVER_SAMPLING = 6.0

    def __init__(self, config: Optional[Dict] = None, *, data_dir: Optional[Path] = None,
                 validator: Optional[RandomXValidator] = None,
                 executor: Optional[ThreadPoolExecutor] = None):
        super().__init__("range", config)
        base_dir = Path(os.environ.get("IAZAR_BASE", Path(__file__).resolve().parents[2]))
        self.data_dir = data_dir or (base_dir / "data")
        self.output_path = self.data_dir / "range_generated_nonces.csv"
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        self.validator = validator or RandomXValidator(self.config)
        self._ext_executor = executor  # Si no es None, no crear nuevos pools efímeros
        self._lock = threading.RLock()
        self._rng = random.SystemRandom()
        self._ranges: List[Tuple[int, int]] = self._load_ranges_from_config()
        if not self._ranges:
            self._ranges = self.DEFAULT_RANGES.copy()
        self._range_stats = {r: {"attempts": 0, "success": 0} for r in self._ranges}
        self._recent_cache: List[int] = []  # FIFO limitada
        self._over_sampling = self.config.get("range_over_sampling", 3.0)
        self._over_sampling = float(min(self.MAX_OVER_SAMPLING, max(self.MIN_OVER_SAMPLING, self._over_sampling)))
        self.logger = logging.getLogger("generator.range")
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
            handler.setFormatter(fmt)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        self.logger.info("RangeBasedGenerator inicializado | ranges=%s oversampling=%.2f", self._ranges, self._over_sampling)

    # ----------------- Config / Ranges -----------------
    def _load_ranges_from_config(self) -> List[Tuple[int, int]]:
        ranges_cfg = (self.config or {}).get("range_success_windows")
        parsed: List[Tuple[int, int]] = []
        if not ranges_cfg:
            return parsed
        for item in ranges_cfg:
            try:
                a, b = int(item[0]), int(item[1])
                if 0 <= a <= b <= self.MAX_NONCE:
                    parsed.append((a, b))
            except Exception:
                continue
        return parsed

    # ----------------- Public API -----------------
    def run_generation(self, block_height: int, block_data: dict, batch_size: int = 500) -> List[dict]:
        start = time.perf_counter()
        with self._lock:
            recent = self._load_recent_nonces(limit=self.RECENT_NONCES_TARGET)
        candidates = self._generate_candidates(int(batch_size * self._over_sampling))
        val_mask = self._validate_parallel(candidates, block_data)
        valid: List[dict] = []
        for idx, ok in enumerate(val_mask):
            if not ok:
                continue
            nonce = candidates[idx] & self.MAX_NONCE
            metrics = self._compute_metrics(nonce, recent)
            record = {
                "nonce": nonce,
                "entropy": metrics["entropy"],
                "uniqueness": metrics["uniqueness"],
                "zero_density": metrics["zero_density"],
                "pattern_score": metrics["pattern_score"],
                "is_valid": True,
                "block_height": block_height,
            }
            valid.append(record)
            recent.add(nonce)
            if len(valid) >= batch_size:
                break
        self._persist(valid)
        elapsed = time.perf_counter() - start
        rate = (len(valid) / elapsed) if elapsed else 0.0
        self._tune_over_sampling(len(valid), batch_size, elapsed)
        self.logger.info("block=%s valid=%d target=%d elapsed=%.3fs rate=%.1f/s oversampling=%.2f", block_height, len(valid), batch_size, elapsed, rate, self._over_sampling)
        return valid

    # ----------------- Candidate Generation -----------------
    def _pick_range_weighted(self) -> Tuple[int, int]:
        # Roulette wheel basada en éxito reciente; +1 para suavizado Laplace
        weights = []
        for r in self._ranges:
            stats = self._range_stats[r]
            success = stats["success"] + 1
            attempts = stats["attempts"] + 2
            weights.append(success / attempts)
        total = sum(weights)
        rpick = self._rng.random() * total
        acc = 0.0
        for r, w in zip(self._ranges, weights):
            acc += w
            if rpick <= acc:
                return r
        return self._ranges[-1]

    def _generate_candidates(self, n: int) -> List[int]:
        out: List[int] = []
        while len(out) < n:
            a, b = self._pick_range_weighted()
            val = self._rng.randint(a, b) & self.MAX_NONCE
            out.append(val)
            self._range_stats[(a, b)]["attempts"] += 1
        return out

    # ----------------- Validation -----------------
    def _validate_parallel(self, nonces: List[int], block_data: dict) -> List[bool]:
        if not nonces:
            return []
        results = [False] * len(nonces)
        executor = self._ext_executor or ThreadPoolExecutor(max_workers=self.MAX_VALIDATION_WORKERS)
        try:
            futures = {executor.submit(self.validator.validate, n, block_data): i for i, n in enumerate(nonces)}
            for fut in as_completed(futures):
                i = futures[fut]
                try:
                    ok = bool(fut.result())
                except Exception as e:
                    self.logger.debug("validation error nonce=%d err=%s", nonces[i], e)
                    ok = False
                results[i] = ok
                if ok:
                    # Heurística de éxito por rango
                    for r in self._ranges:
                        if r[0] <= nonces[i] <= r[1]:
                            self._range_stats[r]["success"] += 1
                            break
        finally:
            if self._ext_executor is None:
                executor.shutdown(wait=False, cancel_futures=True)
        return results

    # ----------------- Metrics -----------------
    def _compute_metrics(self, nonce: int, recent: Set[int]) -> Dict[str, float]:
        bits = np.unpackbits(np.array([nonce], dtype=np.uint32).view(np.uint8))  # 32 bits
        ones = bits.sum()
        zeros = 32 - ones
        p0 = zeros / 32
        p1 = ones / 32
        entropy = - (p0 * np.log2(p0 + 1e-12) + p1 * np.log2(p1 + 1e-12))
        zero_density = p0
        # Runs
        diffs = np.diff(bits)
        transitions = np.count_nonzero(diffs)
        # Longest run (simple scan)
        max_run = 1
        current = 1
        for i in range(1, bits.size):
            if bits[i] == bits[i-1]:
                current += 1
                if current > max_run:
                    max_run = current
            else:
                current = 1
        pattern_score = max(0.5, 1.0 - min(0.3, max_run / 32) + min(0.2, transitions / 31))
        uniqueness = self._uniqueness_hamming(nonce, recent)
        return {
            "entropy": round(float(entropy), 5),
            "uniqueness": round(uniqueness, 5),
            "zero_density": round(float(zero_density), 5),
            "pattern_score": round(float(pattern_score), 5),
        }

    def _uniqueness_hamming(self, nonce: int, recent: Set[int]) -> float:
        if not recent:
            return 1.0
        arr_recent = np.frombuffer(bytearray().join(int(r).to_bytes(4, 'little') for r in recent), dtype=np.uint32)
        xor_vals = arr_recent ^ nonce
        # popcount vectorizada
        # NumPy no tiene popcount directo hasta versiones recientes; fallback Python vectorizado
        popcnt = np.fromiter((int(bin(x).count('1')) for x in xor_vals), dtype=np.int16, count=xor_vals.size)
        avg = popcnt.mean() / 32.0
        return float(min(0.99, max(0.8, avg)))

    # ----------------- Persistence -----------------
    def _persist(self, rows: List[Dict]):
        if not rows:
            return
        new_file = not self.output_path.exists()
        try:
            with self.output_path.open("a", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
                if new_file:
                    writer.writeheader()
                safe_rows = []
                for r in rows:
                    safe = {k: r.get(k) for k in CSV_FIELDS}
                    # Protección mínima CSV injection para campos string (ninguno aquí, pero por consistencia)
                    for k, v in safe.items():
                        if isinstance(v, str) and v and v[0] in ('=', '+', '-', '@'):
                            safe[k] = "'" + v
                    safe_rows.append(safe)
                writer.writerows(safe_rows)
        except Exception as e:
            self.logger.error("persist error path=%s err=%s", self.output_path, e)

    # ----------------- Recent Nonces Cache -----------------
    def _load_recent_nonces(self, limit: int) -> Set[int]:
        # Lectura eficiente sólo de las últimas líneas.
        recent: Set[int] = set()
        if not self.output_path.exists():
            return recent
        try:
            # Leer al revés sin cargar todo: simple approach (puede optimizarse con mmap si crece)
            with self.output_path.open('rb') as fb:
                fb.seek(0, os.SEEK_END)
                pos = fb.tell()
                lines: List[bytes] = []
                while pos > 0 and len(lines) < (limit * 2):  # multiplicador para descartar inválidos
                    step = min(4096, pos)
                    pos -= step
                    fb.seek(pos)
                    chunk = fb.read(step)
                    parts = chunk.split(b"
")
                    # Re-ensamblar última línea si cortada
                    if lines:
                        parts[-1] += lines[-1]
                        lines = lines[:-1]
                    lines.extend(parts)
                # Procesar últimas líneas en orden inverso
                for raw in reversed(lines):
                    try:
                        line = raw.decode('utf-8').strip()
                    except UnicodeDecodeError:
                        continue
                    if not line or line.startswith('nonce'):
                        continue
                    cols = line.split(',')
                    if len(cols) < 7:
                        continue
                    nonce_val = int(cols[0]) & self.MAX_NONCE
                    is_valid = cols[5].lower() == 'true'
                    if is_valid:
                        recent.add(nonce_val)
                        if len(recent) >= limit:
                            break
        except Exception as e:
            self.logger.debug("recent load error err=%s", e)
        return recent

    # ----------------- Oversampling Adaptive Tuning -----------------
    def _tune_over_sampling(self, produced: int, target: int, elapsed: float):
        if target <= 0:
            return
        ratio = produced / target if target else 0
        # Ajustar suavemente
        if ratio < 0.8:
            self._over_sampling = min(self._over_sampling * 1.15, self.MAX_OVER_SAMPLING)
        elif ratio > 1.1:
            self._over_sampling = max(self._over_sampling * 0.9, self.MIN_OVER_SAMPLING)
        # Si tiempo por batch > 1s, bajar oversampling
        if elapsed > 1.0:
            self._over_sampling = max(self.MIN_OVER_SAMPLING, self._over_sampling * 0.9)

    # ----------------- Hot Reload (opcional) -----------------
    def update_ranges(self, new_ranges: Iterable[Tuple[int, int]]):
        with self._lock:
            valid = []
            for a, b in new_ranges:
                a, b = int(a), int(b)
                if 0 <= a <= b <= self.MAX_NONCE:
                    valid.append((a, b))
            if valid:
                self._ranges = valid
                # Reset stats pero conservar oversampling
                self._range_stats = {r: {"attempts": 0, "success": 0} for r in self._ranges}
                self.logger.info("ranges updated=%s", self._ranges)